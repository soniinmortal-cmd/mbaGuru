@extends('admin_template')
@section('css')
@endsection
@section('content') 
<div class="col-md-12">
    <div id="topbar-right-menu"  >
      <button id="downloadExcel" class="btn btn-primary" style="float:right;margin-top:10px;">Download Excel</button>
        <div class="row ">
            <?php
                $i=1;
                $id = request()->id;
                $ansdata =array();
                $positive = array();
                $negative = array();
                $data = 1;
                $muser_id = array();
                $newreports = DB::table('student_quizes')
                    ->where('test_id',$id)
                    ->get();
                foreach($newreports as $newreport){
                    $muser_id[] = $newreport->user_id;
                }
                $studentlogs = DB::table('studentlogs')
                            ->whereIn('id',$muser_id)
                            ->orderBy('id','desc')
                            ->get();
            
            ?>
            <div class=" col-md-4" style="margin-top:20px;">            
                <table id="" class="table table-bordered table-responsive myTable">
                    <!--<h5 colspan = "3">user data</h5>-->
                    <thead>
                        <tr>
                            <th colspan="3">user data</th>
                        </tr>
                    </thead>
                    <tbody> 
                        <tr>
                            <td>s no.</td>
                            <td>name</td>
                            <td>email</td>
                        </tr>
                    </tbody>
                    <tbody>
                        @foreach($studentlogs as $studentlog) 
                        <tr>  
                            <td>{{$i++}}</td>
                            <td>{{$studentlog->name}}</td>
                            <td>{{$studentlog->email}}</td> 
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class=" col-md-4" style="margin-top:20px;">
                <table id="" class="table table-bordered table-responsive myTable">
                    <!-- <tbody>-->
                    <!--    <tr>-->
                    <!--        <td colspan="7">Verbal and Reading Comprehension</td>-->
                    <!--    </tr>-->
                    <!--</tbody>-->
                    <tbody>
                        <tr> 
                            <td>Attempt</td>
                            <td>Missed</td>
                            <td>Correct</td>
                            <td>InCorrect</td>
                            <td>Score</td>
                            <td>Percentage%</td>
                            <td>Time Taken(sec)</td>  
                        </tr>
                    </tbody>
                    <tbody>
                    <?php
                    
                    $ansdata =array();
                    $positive = array();
                    $negative = array();
                    $an1 = array();
                    ?>
                    @foreach($studentlogs as $studentlog)
                    <?php
                        $student_quizes = DB::table('student_quizes')
                                        ->where('user_id',$studentlog->id)
                                        ->where('test_id',$id)
                                        ->where('section_type', 'like', "%VERBAL%")
                                        ->get();
                            foreach($student_quizes as $student_quize){
                                $aners = explode(',',$student_quize->answer);
                                $question_id = explode(',',$student_quize->question_id);
                                $totaltime = explode(',',$student_quize->ans_duration);
                                $totaltime1 = array_sum($totaltime);
                                $attempttime = date("H:i:s", $totaltime1 / 1000);

                                $ques_ans = DB::table('excel_questions')
                                            ->where('test_id',$id)
                                            ->whereIn('id', $question_id)
                                            ->get();

                                foreach($ques_ans as $qst)
                               {
                                  $ansdata[] =   $qst->correct_option;
                                  $positive[] = $qst->positive_mark;
                                  $negative[] = $qst->negative_mark;
                               }
                              
                               $resultt = array_diff_assoc($ansdata, $aners);
                               $correct = array_diff_assoc($ansdata,$resultt);
                            }

                            $result = [];
                            if(isset($question_id)){
                                foreach ($question_id as $key => $value) {
                                    $result[$key] = isset($aners[$key]) ? $aners[$key] : '';
                                    }
                            }
                            $filteredArray = array_filter($result, function($value) {
                                return $value === '';
                            });
                            $filteredArray = $filteredArray ?? [];
                            $totalskip = count($filteredArray);
                            $aners = $aners ?? [];
                            $an1[] = count($aners);
                            $correct = $correct ?? [];
                            $incorrect = count($aners) - count($correct);

                            $pos = array_intersect_key($positive ,$correct);
                            $pos1 = array_sum($pos);

                            $a = array();
                            for($i =0;$i<$incorrect; $i++)
                            {
                              $a[$i] = 1.0; 
                            }

                            $neg = array_intersect_key($negative,$a);
                            $counts = array_count_values($neg);
                           
                            if (isset($counts[1.0])) {
                              $neg2 = $counts[1.0];
                            } else {
                                $neg2 = 0; 
                            }
                           
                            $neg1 = array_sum($neg);
                            $totalmark = $pos1 - $neg2;
                            $show_answer = count($aners);
                            if($show_answer == 0)
                              {
                                  $show_answer123 = 1;
                              }else{
                                  $show_answer123 = $show_answer;
                                  
                            }

                            $ctrc =  count($correct);
                               $per1 = ($ctrc/$show_answer123)*100;
                               $per3 = number_format($per1, 2, '.', '');
                              if($per3 <= -1){
                                  $per2 = 0;
                                
                              }else{
                                  $per2 =  $per3;
                              
                              } 
                    ?>
                    <tr>
                        <td>{{count($aners)}}</td>
                        <td>{{$totalskip}}</td>
                        <td>{{count($correct)}}</td>
                        <td>{{$incorrect}}</td>
                        <td>{{$totalmark}}</td>
                        <td>{{$per2}}</td>
                        <td>{{$attempttime}}</td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <?php
             $ansdata =array();
             $positive = array();
             $negative = array();
             $an2 = array();
            ?>
            <div class=" col-md-4" style="margin-top:20px;">
                <!--<h5>Data Interpretation & Logical Reasoning</h5>-->
                <table id="" class="table table-bordered table-responsive myTable ">
                    <!--<tbody>-->
                    <!--    <tr>-->
                    <!--        <td colspan="7">Data Interpretation & Logical Reasoning</td>-->
                    <!--    </tr>-->
                    <!--</tbody>-->
                    <tbody>
                        <tr>
                            <td>Attempt</td>
                            <td>Missed</td>
                            <td>Correct</td>
                            <td>InCorrect</td>
                            <td>Score</td>
                            <td>Percentage%</td>
                            <td>Time Taken(sec)</td>
                        </tr>
                    </tbody>
                <tbody>
                @foreach($studentlogs as $studentlog)
                    <?php
                        $student_quizes = DB::table('student_quizes')
                                            ->where('user_id',$studentlog->id)
                                            ->where('test_id',$id)
                                            ->where('section_type', 'like', "%Data%")
                                            ->get();
                        foreach($student_quizes as $student_quiz)
                        {
                            $aners1 = explode(',',$student_quiz->answer);
                            $aners = array_filter($aners1);
                            $question_id = explode(',',$student_quiz->question_id);
                            $totaltime = explode(',',$student_quiz->ans_duration);
                            $totaltime1 = array_sum($totaltime);
                            $attempttime = date("H:i:s", $totaltime1 / 1000);
                            
                            $ques_ans = DB::table('excel_questions')
                                            ->where('test_id',$id)
                                            ->whereIn('id', $question_id)
                                            ->get();

                            foreach($ques_ans as $qst)
                            {
                                $ansdata[] =   $qst->correct_option;
                                $positive[] = $qst->positive_mark;
                                $negative[] = $qst->negative_mark;
                            }
                            $resultt = array_diff_assoc($ansdata, $aners);
                            $correct = array_diff_assoc($ansdata,$resultt);
                        }

                        $result = [];
                        if(isset($question_id)){
                            foreach ($question_id as $key => $value) {
                                $result[$key] = isset($aners[$key]) ? $aners[$key] : '';
                                }
                        }
                        $filteredArray = array_filter($result, function($value) {
                            return $value === '';
                        });
                        $filteredArray = $filteredArray ?? [];
                        $totalskip = count($filteredArray);
                        $totalskip2 = $totalskip;
                        $aners = $aners ?? [];
                        $aners2 = $aners;
                        $an2[] = count($aners2);

                        $correct = $correct ?? [];
                        $correct2 = $correct;
                        $incorrect = count($aners) - count($correct);
                        $incorrect2 = $incorrect;
                        $pos = array_intersect_key($positive ,$correct);
                        $pos1 = array_sum($pos);

                        $a = array();
                        for($i =0;$i<$incorrect; $i++)
                        {
                          $a[$i] = 1.0; 
                        }

                        $neg = array_intersect_key($negative,$a);
                        $counts = array_count_values($neg);
                       
                        if (isset($counts[1.0])) {
                          $neg2 = $counts[1.0];
                        } else {
                            $neg2 = 0; 
                        }
                       
                        $neg1 = array_sum($neg);
                        $totalmark = $pos1 - $neg2;
                        $totalmark2 = $totalmark;
                        $show_answer = count($aners);
                        if($show_answer == 0)
                          {
                              $show_answer123 = 1;
                          }else{
                              $show_answer123 = $show_answer;
                              
                        }

                        $ctrc =  count($correct);
                           $per1 = ($ctrc/$show_answer123)*100;
                           $per3 = number_format($per1, 2, '.', '');
                          if($per3 <= -1){
                              $per2 = 0;
                            
                          }else{
                              $per2 =  $per3;
                          
                          }
                          $per22 = $per2;
                         
                    ?>
                        <tr>
                        <td>{{count($aners2)}}</td>
                        <td>{{$totalskip2}}</td>
                        <td>{{count($correct2)}}</td>
                        <td>{{$incorrect2}}</td>
                        <td>{{$totalmark2}}</td>
                        <td>{{$per22}}</td>
                        <td>{{$attempttime}}</td>
                        </tr>
                    @endforeach
                </tbody>
                </table>
            </div> 
            <?php
             $ansdata =array();
             $positive = array();
             $negative = array();
             $an3 = array();
            ?>
             <div class=" col-md-4" style="">
                <!--<h5>Quantitative Aptitude</h5>-->
                <table id="" class="table table-bordered table-responsive myTable ">
                     <!--<tbody>-->
                     <!--   <tr>-->
                     <!--       <td colspan="7">Quantitative Aptitude</td>-->
                     <!--   </tr>-->
                    <!--</tbody>-->
                <tbody>
                    <tr>
                        <td>Attempt</td>
                        <td>Missed</td>
                        <td>Correct</td>
                        <td>InCorrect</td>
                        <td>Score</td>
                        <td>Percentage%</td>
                        <td>Time Taken(sec)</td>
                    </tr>
                </tbody>
                <tbody>
                @foreach($studentlogs as $studentlog)
                    <?php
                        $student_quizes = DB::table('student_quizes')
                                            ->where('user_id',$studentlog->id)
                                            ->where('test_id',$id)
                                            ->where('section_type', 'like', "%Quantitative%")
                                            ->get();
                        foreach($student_quizes as $student_quiz)
                        {
                            $aners1 = explode(',',$student_quiz->answer);
                            $aners = array_filter($aners1);
                            $question_id = explode(',',$student_quiz->question_id);
                            $totaltime = explode(',',$student_quiz->ans_duration);
                            $totaltime1 = array_sum($totaltime);
                            $attempttime = date("H:i:s", $totaltime1 / 1000);
                            $ques_ans = DB::table('excel_questions')
                                            ->where('test_id',$id)
                                            ->whereIn('id', $question_id)
                                            ->get();

                            foreach($ques_ans as $qst)
                            {
                                $ansdata[] =   $qst->correct_option;
                                $positive[] = $qst->positive_mark;
                                $negative[] = $qst->negative_mark;
                            }
                            $resultt = array_diff_assoc($ansdata, $aners);
                            $correct = array_diff_assoc($ansdata,$resultt);
                        }

                        $result = [];
                        if(isset($question_id)){
                            foreach ($question_id as $key => $value) {
                                $result[$key] = isset($aners[$key]) ? $aners[$key] : '';
                                }
                        }
                        
                  
                        $filteredArray = array_filter($result, function($value) {
                            return $value === '';
                        });
                        $filteredArray = $filteredArray ?? [];
                        $totalskip = count($filteredArray);
                        $totalskip3 = $totalskip;
                        $aners = $aners ?? [];
                        $aners3 = $aners;
                        $an3[] = count($aners3);
                        $correct = $correct ?? [];
                        $correct3 = $correct;
                        $incorrect = count($aners) - count($correct);
                        $incorrect3 = $incorrect;
                        $pos = array_intersect_key($positive ,$correct);
                        $pos1 = array_sum($pos);
                        $a = array();
                        for($i =0;$i<$incorrect; $i++)
                        {
                          $a[$i] = 1.0; 
                        }
                        $neg = array_intersect_key($negative,$a);
                        $counts = array_count_values($neg);
                        if (isset($counts[1.0])) {
                          $neg2 = $counts[1.0];
                        } else {
                            $neg2 = 0; 
                        }
                        $neg1 = array_sum($neg);
                        $totalmark = $pos1 - $neg2;
                        $totalmark3 =$totalmark;
                        $show_answer = count($aners);
                        if($show_answer == 0)
                        {
                             $show_answer123 = 1;
                        }else{
                            $show_answer123 = $show_answer;
                              
                        }

                        $ctrc =  count($correct);
                           $per1 = ($ctrc/$show_answer123)*100;
                           $per3 = number_format($per1, 2, '.', '');
                          if($per3 <= -1){
                              $per2 = 0;
                            
                          }else{
                              $per2 =  $per3;
                          
                          }
                          $per23 = $per2;
                    ?>
                        <tr>
                            <td>{{count($aners3)}}</td>
                            <td>{{$totalskip3}}</td>
                            <td>{{count($correct3)}}</td>
                            <td>{{$incorrect3}}</td>
                            <td>{{$totalmark3}}</td>
                            <td>{{$per23}}</td>
                            <td>{{$attempttime}}</td>
                        </tr>
                        
                    @endforeach
                </tbody>
                </table>
            </div> 

            <?php
             $ansdata =array();
             $positive = array();
             $negative = array();
             $student_quizes = DB::table('student_quizes')
                        ->where('user_id',$studentlog->id)
                        ->where('test_id',$id)
                        ->get();
            ?>
            <?php
             $verbal_ques = DB::table('excel_questions')
                            ->where('section_name', 'like', "%VERBAL%")
                            ->where('test_id',$id)
                            ->get();
            $nnverbal_ques = DB::table('excel_questions')
                        ->where('section_name', 'like', "%VERBAL%")
                    ->where('test_id',$id)
                    ->get();
                        $i = 1;
            ?>

            <div class=" col-md-4" style="">
                <!--<h5></h5>-->
                <table id="" class="table table-bordered table-responsive myTable ">
                    <!-- <tbody>-->
                    <!--    <tr>-->
                    <!--        <td colspan="7">Verbal and Reading Comprehension</td>-->
                    <!--    </tr>-->
                    <!--</tbody>-->
                @foreach($studentlogs as $studentlog)
                    <?php
                    $stuques = DB::table('student_quizes')
                        ->where('test_id', $id)
                        ->where('user_id', $studentlog->id)
                        ->where('section_type', 'like', "%VERBAL%")
                        ->first();

                    if($stuques) {
                        $ans = explode(',', $stuques->answer);
                    } else {
                        $ans = []; 
                    }
                    ?>
                    <tbody>
                    <tr class="">
                        @if($i == 1)
                            @foreach($verbal_ques as $verbal_quess)
                                <td>{{$i++}}</td>
                            @endforeach
                        @endif
                    </tr>
                </tbody>
                    <tbody>
                    <tr class="">
                        @foreach($nnverbal_ques as $key => $verbal_quesse)
                             
                            <?php  if(isset($ans[$key]) && $ans[$key] === $verbal_quesse->correct_option) { ?>
                                    <td>Correct</td>
                               <?php } elseif(empty($ans[$key])) { ?>
                                    <td>Not Attempted </td>
                                <?php } else { ?>
                                    <td>Wrong</td>
                               <?php } ?>
                        @endforeach
                    </tr>
                </tbody>
                @endforeach
                </table>
            </div> 
            <?php
             $data_ques = DB::table('excel_questions')
                            ->where('section_name', 'like', "%Data%")
                           ->where('test_id',$id)
                           ->get();
            $i = 1;
            ?>
        <div class=" col-md-4" style="">
            <!--<h5></h5>-->
                <table id="" class="table table-bordered table-responsive myTable ">
                    <!-- <tbody>-->
                    <!--    <tr>-->
                    <!--        <td colspan="7">Data Interpretation & Logical Reasoning</td>-->
                    <!--    </tr>-->
                    <!--</tbody>-->
                @foreach($studentlogs as $studentlog)
                    <?php
                    $datastuques = DB::table('student_quizes')
                        ->where('test_id', $id)
                        ->where('user_id', $studentlog->id)
                        ->where('section_type', 'like', "%Data%")
                        ->first();

                    if($datastuques) {
                        $ans = explode(',', $datastuques->answer);
                    } else {
                        $ans = []; 
                    }
                    ?>
                    <tbody>
                    <tr class="">
                        @if($i == 1)
                            @foreach($data_ques as $verbal_quess)
                                <td>{{$i++}}</td>
                            @endforeach
                        @endif
                    </tr>
                    </tbody>
                    <tbody>
                    <tr class="">
                        @foreach($data_ques as $key => $verbal_quesse) 
                            <?php  if(isset($ans[$key]) && $ans[$key] === $verbal_quesse->correct_option) { ?>
                                <td>Correct </td>
                                <?php  } elseif(empty($ans[$key])) { ?>
                                     <td>Not Attempted </td>
                                <?php } else { ?>
                                    <td>Wrong </td>
                              <?php  }  ?>
                        @endforeach
                    </tr>
                </tbody>
                @endforeach
                </table>
            </div> 
        <?php
             $qs_ques = DB::table('excel_questions')
                        ->where('section_name', 'like', "%quantitative%")
                        ->where('test_id',$id)
                        ->get();
                        $i = 1;
        ?>
            <div class="col-md-4" style="">
                <!--<h5></h5>-->
                <table id="" class="table table-bordered table-responsive myTable ">
                    <!-- <tbody>-->
                    <!--    <tr>-->
                    <!--        <td colspan="7">Quantitative Aptitude</td>-->
                    <!--    </tr>-->
                    <!--</tbody>-->
                @foreach($studentlogs as $studentlog)
                    <?php
                    $qsstuques = DB::table('student_quizes')
                        ->where('test_id', $id)
                        ->where('user_id', $studentlog->id)
                        ->where('section_type', 'like', "%quantitative%")
                        ->first();

                    if($qsstuques) {
                        $ans = explode(',', $qsstuques->answer);
                    } else {
                        $ans = [];
                    }
                    ?>
                        @if($i == 1)
                            <tr class="">
                                @foreach($qs_ques as $verbal_quess)
                                    <td>{{$i++}}</td>
                                @endforeach
                            </tr>
                        @endif
                        <tbody>
                            
                        <tr class="">
                            @foreach($qs_ques as $key => $verbal_quesse)
                                <?php  if(isset($ans[$key]) && $ans[$key] === $verbal_quesse->correct_option) { ?>     
                                    <td>Correct</td>
                                <?php } elseif(empty($ans[$key])) { ?>
                                    <td>Not Attempted</td>
                                <?php  } else { ?>
                                    <td>Wrong</td>
                                <?php } ?>  
                            @endforeach
                        </tr>
                        
                @endforeach
                </tbody>
                </table>
            </div> 
        </div>
    </div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script> 
// $(document).ready(function() {
//     $('#downloadExcel').click(function() {
//         var tables = $('.myTable');
//         var combinedHtml = '<table>';
//         var topHeaderText = tables.find('h5').text();
//       // combinedHtml += '<tr><th colspan="7">' + topHeaderText + '</th></tr>'; 
//         var headers = [];
//         tables.each(function(index, table) {
//             $(table).find('h5').each(function() {
//                 headers.push($(this).text());
//             });
//         });
//         combinedHtml += '<tr>';
//         headers.forEach(function(header) {
//             combinedHtml += '<th>' + header + '</th>';
//         });
//         combinedHtml += '</tr>';
//         var maxRows = Math.max.apply(null, tables.map(function() {
//             return $(this).find('tbody tr').length;
//         }).get());

//         for (var i = 0; i < maxRows; i++) {
//             combinedHtml += '<tr>';
//             tables.each(function(index, table) {
//                 var $row = $(table).find('tbody tr').eq(i);
//                 var rowData = $row.html() || '';
//                 combinedHtml += '<td>' + rowData + '</td>';
//             });
//             combinedHtml += '</tr>';
//         }

//         combinedHtml += '</table>';

//         $.ajaxSetup({
//             headers: {
//                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//             }
//         });
//         $.ajax({
//             url: "{{ route('admin.download-excel') }}",
//             method: 'POST',
//             data: { html: combinedHtml },
//             xhrFields: {
//                 responseType: 'blob'
//             },
//             success: function(data) {
//                 var a = document.createElement('a');
//                 var url = window.URL.createObjectURL(data);
//                 a.href = url;
//                 a.download = 'student_report.xlsx';
//                 document.body.append(a);
//                 a.click();
//                 a.remove();
//                 window.URL.revokeObjectURL(url);
//             },
//             error: function(xhr, status, error) {
//                 console.error('Error:', error);
//             }
//         });
//     });
// });



//second

$(document).ready(function() {
    $('#downloadExcel').click(function() {
        var tables = $('.myTable');
        var combinedHtml = '<table>';

        // Extract the top header text
        var topHeaderText = tables.find('h5').text();
        
        // Extract headers from the first table
        var headers = [];
        tables.each(function(index, table) {
            $(table).find('thead th').each(function() {
                headers.push($(this).text());
            });
        });

        // Create the top header row
        combinedHtml += '<tr>';
        combinedHtml += '<th colspan="' + headers.length + '">' + topHeaderText + '</th>';
        combinedHtml += '</tr>';

        // Create the headers row
        combinedHtml += '<tr>';
        headers.forEach(function(header) {
            combinedHtml += '<th>' + header + '</th>';
        });
        combinedHtml += '</tr>';

        // Find the maximum number of rows in the tables
        var maxRows = Math.max.apply(null, tables.map(function() {
            return $(this).find('tbody tr').length;
        }).get());

        // Loop through each row index
        for (var i = 0; i < maxRows; i++) {
            combinedHtml += '<tr>';
            tables.each(function(index, table) {
                var $row = $(table).find('tbody tr').eq(i);
                if ($row.length) {
                    $row.find('td').each(function() {
                        combinedHtml += '<td>' + $(this).html() + '</td>';
                    });
                } else {
                    for (var j = 0; j < headers.length; j++) {
                        combinedHtml += '<td></td>';
                    }
                }
            });
            combinedHtml += '</tr>';
        }

        combinedHtml += '</table>';

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: "{{ route('admin.download-excel') }}",
            method: 'POST',
            data: { html: combinedHtml },
            xhrFields: {
                responseType: 'blob'
            },
            success: function(data) {
                var a = document.createElement('a');
                var url = window.URL.createObjectURL(data);
                a.href = url;
                a.download = 'student_report.xlsx';
                document.body.append(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    });
});


</script> 







