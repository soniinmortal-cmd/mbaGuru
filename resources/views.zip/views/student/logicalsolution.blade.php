@extends('student_template')
@section('css')
@endsection
@section('content')
<style>
  .green {
         appearance: none;
         padding: 10px;
         background-color: green;
         border-radius:50%;

      }
      .red {
         appearance: none;
         padding: 10px;
         background-color: red;
         border-radius:50%;
   
      }
   </style>
<div class="container-fluid">
   <?php
    $testid = request()->testid;
    $paperid = request()->paperid;
    $nextid = 'nmat-report';
    ?>
   <div class="row" id="detaildiv" >
      <div class="col-1 pt-3 px-3" id="crossbutton">
      <a href="{{route('student.nmat-report',['id'=>$testid,'paperid'=>$paperid,'nextid'=>$nextid])}}">
         <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
         </svg>
      </a>
      </div>
      <div class="col-8" style="border-right:1px solid lightgray; height:100%;">
         <H6 CLASS="py-3">{{$test->test}}{{$test->testincid}}</h6>
      </div>
      <div class="col-3">
         <?php
         $useremail =session()->get('email');
         ?>
         <h6 class="py-3"><b>User: {{$useremail}}</b></h6>
      </div>
   </div>
   <div class="row">
      <div class="col-9" style="border-right:1px solid lightgray; height:100%;">
         <div class="row">
            <div class="col-12 py-2" style="border-bottom:1px solid lightgray">
               <!-- <button type="button" class="btn btn-outline-secondary verbal">VERBAL AND READING COMPREHENSIVE</button> -->
            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBackdrop" aria-controls="offcanvasWithBackdrop">Logical Reasoning</button>
               <button type="button" class="btn btn-outline-primary">+2 SECTIONS</button>
            </div>
         </div>
         <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasWithBackdrop" aria-labelledby="offcanvasWithBackdropLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBackdropLabel">Change Section</h5>

    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <p>By changing section, you will be shifted to a new section. If you are sure about section change, select any from below.</p>
    <a class="btn btn-outline-secondary my-1  px-auto w-100" href="{{route('student.nmat-solution',['testid'=>$testid,'paperid'=>$paperid])}}">Quantitative Skills</a>
     <a class="btn btn-outline-secondary my-1 px-auto w-100" href="{{route('student.languagesolution',['testid'=>$testid,'paperid'=>$paperid])}}">Language Skills</a>
    <a class="btn btn-outline-secondary my-1 px-auto w-100" href="{{route('student.logicalsolution',['testid'=>$testid,'paperid'=>$paperid])}}">Logical Reasoning</a>
  </div>
</div>
         <div class="row">
            <div class="col-12 py-2">
               <!-- <span>Q. 7 of 24 </span> -->
             <!--   <span>&nbsp;&nbsp;Marks:
               <span class="text-success">&nbsp;3.0,</span>
               <span class="text-secondary">&nbsp;-1.0</span>
               </span> -->
               <div class="row" style="background-color:#fdf7f7; height:50px;">
                  <div class="col-4 py-2">
                      <span>&nbsp;&nbsp;Marks:
               <span class="text-success">&nbsp;3.0,</span>
               <span class="text-secondary">&nbsp;-1.0</span>
               </span>
                     <!-- <span><b>You have missed this question, you scored</b></span> -->
                     <!-- <span class="text-danger"><b>0.0</b></span> -->
                  </div>
                   <?php
                   $artf = array();
                   $qdatay = array();
                   $alluser = array();
                  // $avgtime  = array();
                   $k =1;
                  $qus_id = explode(',', $verbal_reports->ans_duration);
                  foreach($verbal_r as $verbal_rs){
                     $aner[] = explode(',', $verbal_rs->answer);
                     $avgtime[] = explode(',', $verbal_rs->ans_duration);
                     $alluser[] =  $verbal_rs->user_id;
                  }  
             
                  ?>
                 <div class="col-8">
                     <div class="row" >
                        @foreach($verbal_ques as $key=> $ques_p)
                           <div class="anstime ansti{{$k}}" style="display:none;" >
                              @foreach($qus_id as $key1=> $qus_ids)
                                <?php
                                $qtime = date("H:i:s", $qus_ids / 1000);
                                ?>  
                                 @if($key == $key1)
                                    <div class="col-4 text-end" STYLE="float:left">
                                       YOUR TIME</br>{{$qtime}}
                                    </div>
                                 @endif
                              @endforeach
                          <?php
                           $anerwrr = array();
                           $anerwrr1 = array();
                          ?>
                            @foreach($aner as $key2=> $anerw)
                              @foreach($anerw as $key1=> $anerws)
                                 @if($key == $key1)
                                  
                                    @if($ques_p->correct_option == $anerws)
                                    <?php
                                   $anerwrr[] = $anerws;
                                   
                                    ?>
                                    @endif
                                     @if($ques_p->correct_option != $anerws)
                                    <?php
                                   $anerwrr1[] = $anerws;
                                   
                                    ?>
                                    @endif
                                 @endif
                              @endforeach
                           @endforeach 

                           <?php
                          $tota0 =  (count($anerwrr))+(count($anerwrr1));
                          if($tota0 ==0){
                           $tota0 =1;
                          }
                           $da1 = count($anerwrr);
                           
                          // $newans =($da1/$tota0) *100;
                           $newans = ceil(($da1/$tota0) *100);

                          
                           ?>

                           <!--  <div class="col-4 text-end " STYLE="float:left">
                               OVERALL CORRECT:<br/>{{count($anerwrr)}}
                           </div> -->

                           <div class="col-4 text-end " STYLE="float:left; ">
                               OVERALL CORRECT:</br>{{$newans}}%
                           </div>
                              <?php
                              $dtw = array();
                              ?>

                           <!--avragetime-->
                           @foreach($avgtime as $key3=> $avgtimes)
                            @foreach($avgtimes as $key4=> $avgtimess)
                           <?php
                           //echo'<pre>';
                         $dtw[] =  $avgtimess;
                          // dd($avgtimess);
                           ?>
                           @endforeach
                           @endforeach
                           <!--endavrg-->

                          
                           <?php
                           $totaltime =  array_sum($dtw);
                           $numberuser = count($alluser);
                           $avg = $totaltime/$numberuser;
                           $tid = date("H:i:s", $avg / 1000);
                        
                           ?>
                              <div class="col-4 text-end " STYLE="float:left">
                             ON AVG. TIME<br/>{{$tid}}
                           </div>

                               </div>
                           <?php $k++; ?>
                        @endforeach
                     
                          
                     </div>
                  </div>
               </div>
            <div class="maindiv">
               <?php
               $i =1;
               $ans = explode(',', $verbal_reports->answer);
               ?>
                @foreach($verbal_ques as $key=> $ques_paper)
                 @if((empty($ques_paper->instruction))  || ($ques_paper->instruction == 'empty'))
                
               <div class="row ques{{$i}} qusn" style="display:none;">
                   <div class="col-12"id="divcontent">
                       <b>Q{{$i}}.</b><?= htmlspecialchars_decode($ques_paper->question) ?>
                       <br/>
                      ANSWER:
                     
                      @if($ques_paper->question_type =='MULTI_CHOICE' || ($ques_paper->question_type == 'multiple'))

                      @if($ques_paper->status == 1)
                                    <ol class="choices">
                                       <?php
                                          $ansstr = $ques_paper->answer;
                                          $ans = explode(",",$ansstr);
                                          $lk =1;
                                          ?>
                                       @foreach($ans as $value)
                                       <li>{{$lk}}
                                          <span>
                                          <?= htmlspecialchars_decode($value) ?>
                                          
                                          </span>
                                       </li>
                                       <?php $lk++; ?>
                                       @endforeach
                                    </ol>
                                    @else
                                                                   <!--start-->
                                         <ol class="choices">
                                    @foreach($ans as $key1=> $anss)                   
                                       @if($key == $key1)
                                      
                                       @if($anss ==1)
                                       @if($ques_paper->correct_option ==1)
                                          <li > <input type="radio" name="options"  class="green"/><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @elseif($ques_paper->correct_option !=1)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"   /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @endif

                                       @if($anss ==2)
                                       @if($ques_paper->correct_option ==2)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @elseif($ques_paper->correct_option !=2)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"   /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"   /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @endif

                                        @if($anss ==3)
                                       @if($ques_paper->correct_option ==3)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @elseif($ques_paper->correct_option !=3)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @endif




                                       @if($anss ==4)
                                       @if($ques_paper->correct_option ==4)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @elseif($ques_paper->correct_option !=4)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @endif




                                          @if($ques_paper->option5)
                                         


                                       @if($anss ==5)
                                       @if($ques_paper->correct_option ==5)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option5) ?></span></li>
                                          @elseif($ques_paper->correct_option !=5)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option5) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option5) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @endif


                                          @endif
                                      
                                          @endif
                                    @endforeach
                                     </ol>
                                    <!--end-->
                                    @endif
                      @else
                         @foreach($ans as $key1=> $anss)                   
                     @if($key == $key1)
                       {{$anss}}
                     @endif
                     @endforeach
                      @endif
                  </div> 
                  <!-- <div class="corretans cns{{$i}}" style="display:none"><span class="text-success">Correct Answer{{$ques_paper->correct_option}}</span></div> -->
               </div>
               @else
                <div class="row ques{{$i}} qusn" style="display:none;">
                  <div class="col-6" id="divcontent" style="width:50%; float:left;">
                    <?= htmlspecialchars_decode($ques_paper->instruction) ?>
                  </div>
                   <div class="col-6" id="divcontent" style="width:50%; float:left;">
                     <b>Q{{$i}}.</b><?= htmlspecialchars_decode($ques_paper->question) ?>

                     ANSWER:
                     @if($ques_paper->question_type =='MULTI_CHOICE' || ($ques_paper->question_type == 'multiple'))
                                    @if($ques_paper->status == 1)
                                       <ol class="choices">
                                          <?php
                                             $ansstr = $ques_paper->answer;
                                             $ans = explode(",",$ansstr);
                                             $lk =1;
                                             ?>
                                          @foreach($ans as $value)
                                          <li>
                                             {{$lk}}<span>
                                            <?= htmlspecialchars_decode($value) ?>
                                             
                                             </span>
                                          </li>
                                          <?php $lk++; ?>
                                          @endforeach
                                       </ol>
                                    @else
                                                                      <!--start-->
                                         <ol class="choices">
                                    @foreach($ans as $key1=> $anss)                   
                                       @if($key == $key1)
                                      
                                       @if($anss ==1)
                                       @if($ques_paper->correct_option ==1)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @elseif($ques_paper->correct_option !=1)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @endif

                                       @if($anss ==2)
                                       @if($ques_paper->correct_option ==2)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @elseif($ques_paper->correct_option !=2)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option2) ?></span></li>
                                          @endif

                                        @if($anss ==3)
                                       @if($ques_paper->correct_option ==3)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @elseif($ques_paper->correct_option !=3)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option3) ?></span></li>
                                          @endif




                                       @if($anss ==4)
                                       @if($ques_paper->correct_option ==4)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @elseif($ques_paper->correct_option !=4)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option4) ?></span></li>
                                          @endif




                                          @if($ques_paper->option5)
                                         


                                       @if($anss ==5)
                                       @if($ques_paper->correct_option ==5)
                                          <li > <input type="radio" name="options"  class="green" /><span><?= htmlspecialchars_decode($ques_paper->option5) ?></span></li>
                                          @elseif($ques_paper->correct_option !=5)
                                          <li > <input type="radio" name="options"  class="red" /><span><?= htmlspecialchars_decode($ques_paper->option5) ?></span></li>
                                          @else
                                           <li style="background-color:gray"> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option5) ?></span></li>
                                          @endif
                                          @else
                                           <li> <input type="radio" name="options"  checked="checked" /><span><?= htmlspecialchars_decode($ques_paper->option1) ?></span></li>
                                          @endif


                                          @endif
                                      
                                          @endif
                                    @endforeach
                                     </ol>
                                    <!--end-->
                                    @endif
                                    @else
                                       @foreach($ans as $key1=> $anss)                   
                     @if($key == $key1)
                       {{$anss}}
                     @endif
                     @endforeach
                      @endif
                  </div> 
                   <!-- <div class="corretans cns{{$i}}" style="display:none"><span class="text-success"> Correct Answer: {{$ques_paper->correct_option}}</span></div> -->
               </div>
               @endif
               <?php $i++; ?>
               @endforeach
            </div>
               <div class="row">
                <!--   <div class="col-12 py-2">
                    <button type="button" class="btn btn-primary showcorrect" >Correct Answer</button>
                    <?php
                    $m =1;
                    ?>
                     @foreach($verbal_ques as $key=> $ques_paper)
                        <div class="correctans cans{{$m}}" style="display:none;">
                           {{$ques_paper->correct_option}}
                        </div>
                        <?php $m++;?>
                     @endforeach
                 </div> -->
                  <div class="col-12 py-2">
                     <button type="button" class="btn btn-primary expt" data-bs-toggle="modal" data-bs-target="#exampleModal" data-set="">EXPALANTION&nbsp;&nbsp;<i class='fas fa-arrow-right'></i></button>
                      <button type="button" class="btn btn-primary exptt" data-bs-toggle="modal" data-bs-target="#exampleModal1" data-set="">Correct Answer&nbsp;&nbsp;<i class='fas fa-arrow-right'></i></button>

                     <a type="button" class="btn btn-primary nxt" STYLE="float:right">NEXT&nbsp;&nbsp;<i class='fas fa-arrow-right'></i></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-3">
         <div class="buttondiv">
            <?php
            $j =1;
            ?>

             @foreach($verbal_ques as $ques_paper)
            <button type="button" class="btn btn-secondary buttonround mt-2 mx-1 ans{{$j}} answer" data-value="{{$j}}">{{$j}}</button>
           
             <?php $j++; ?>
            @endforeach
         </div>
         <div id="identation">
            <div class="row">
               <div class="col-12">
                  <div style="height:20px; width:20px; background-color:green; border-radius:50%; margin:5px; float:left"></div>
                  <div style="float:left; margin-top:4px">
                     <p>CORRECT ANSWER</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-6">
                  <div style="height:20px; width:20px; background-color:RED; border-radius:50%; margin:5px; float:left"></div>
                  <div style="float:left; margin-top:4px">
                     <p>WRONG ANSWER</p>
                  </div>
               </div>
               <div class="col-6">
                  <div style="height:20px; width:20px; background-color:lightgrey; border-radius:50%; margin:5px; float:left"></div>
                  <div style="float:left; margin-top:4px">
                     <p>NOT ANSWER</p>
                  </div>
               </div>
            </div>
         </div>
         <div>
            <!-- <button type="button" class="btn bg-transparent">ALL QUESTION</button> -->
              <?php
            $sectionid =3;
            ?>
             <!-- <a class="btn btn-default" href="{{route('student.solution-question',['testid'=>$testid,'sectionid'=>$sectionid,'paperid'=>$paperid])}}">ALL QUESTION</a> -->
            <!-- <button type="button" class="btn bg-transparent">INSTRUCTION</button> -->

             <!-- <a class="btn btn-default" href="{{route('student.solution-instruction',['testid'=>$testid,'sectionid'=>$sectionid,'paperid'=>$paperid])}}">INSTRUCTION
            </a> -->
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Answer Explanation</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                     <?php 
                      $l =1; 
                     ?>
                      @foreach($verbal_ques as $ques_paper)
                     <div class="expl excp{{$l}}" style="display:none;"><?= htmlspecialchars_decode($ques_paper->answer_explanation) ?></div>
                     <?php $l++;?>
                     @endforeach
                    </div>
                </div>
            </div>
        </div>

<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Correct Answer</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                     <?php 
                      $lk =1; 
                     ?>
                      @foreach($verbal_ques as $ques_paper)
                     <div class="cre crtc{{$lk}}" style="display:none;"><?= htmlspecialchars_decode($ques_paper->correct_option) ?></div>
                     <?php $lk++;?>
                     @endforeach
                    </div>
                </div>
            </div>
</div>
        <script type="text/javascript" src="{{asset('assets/admin/js/solution.js')}}"></script>
@endsection
@section('css') 
@endsection