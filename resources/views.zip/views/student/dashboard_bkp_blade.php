@extends('student_template')
<style>
   .dropdown-menu{
   width: max-content !important;
   }
   .ml-auto{
   margin-left:auto;
   }

   .input-box{
  width:150px
}
</style>
@section('css')
@endsection
@section('content')

<div class="col-md-9 bg-light py-3 " id="right-menu-bar">
   <div id="topbar-right-menu " class="d-flex  px-3 my-3 justify-content-between align-items-center">
      {{-- <h5 class="fw-bold text-capitalize">Dashboard</h5> --}}
   </div>
   <?php
        $userid =session()->get('id');
        $reports = DB::table('student_quizes')
                        ->where('user_id',$userid)
                        ->where('section_type','verbal')
                        ->get();
        $ps = DB::table('publish_statuses')->where('status',1)->get();
        $tests = DB::table('tests')->get();
        $test_id  = array();
        $ps_id = array();
        $ans_id = array();
        $id = array();
        foreach($tests as $test)
        {
            $id[] = $test->id;
        }
        foreach($reports as $report)
        {
            $test_id[] = $report->paper_id;
            $ans_id[] = explode(",",$report->answer);
        }
        $all_ans = array_filter($ans_id);
        foreach($ps as $pss)
        {
            $ps = DB::table('tests')->where('id',$pss->test_id)->get();

            $ps_id[] = $pss->id;
        }

        $useremail =session()->get('email');
        $assigment = DB::table('assign_test')->where('email',$useremail)->where('status',1)->get();
        $nnid = array();
       foreach($assigment as $assigments){
        $ntestid = array();
         $testuploading = DB::table('testuploading')->where('title',$assigments->course_id)->get();
         foreach($testuploading as $testuploadings){
            $ntestid = DB::table('tests')->where('course_id',$testuploadings->id)->get();

         }
       $nnid[] = (count($ntestid));
       }
        $newdata = DB::table('student_quizes')
                        ->where('user_id',$userid)
                       ->where('section_type', 'like', "%quantitative%")
                        ->get();


      ?>
   <div class="conatiner-fluid">
      <div class="row">
          @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
 @if(Session::has('message'))
      <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('message') }}</p>
    @endif
         <div class="col-md-6 col-lg-4 col-xlg-3">
            <div class="card card-hover">
               <div class="box bg-cyan text-center">
                  <h1 class="font-light text-white">
                     <img src="{{url('/assets/custom/icons/test.png')}}" alt="Total Tests" class="mt-2">
                  </h1>
                  <h6 class="text-white">Total Tests</h6>
                  <h5 class="text-white">{{count($id)}}</h5>
               </div>
            </div>
         </div>
         <div class="col-md-6 col-lg-4 col-xlg-3 py3">
            <div class="card card-hover">
               <div class="box bg-cyan1  text-center">
                  <h1 class="font-light text-white">
                     <img src="{{url('/assets/custom/icons/released.png')}}" alt="Tests Released" class="mt-2">
                  </h1>
                  <h6 class="text-white">Tests Released</h6>
                  <h5 class="text-white">{{array_sum($nnid)}}</h5>
               </div>
            </div>
         </div>
         <div class="col-md-6 col-lg-4 col-xlg-3">
            <div class="card card-hover">
               <div class="box bg-cyan2 text-center">
                  <h1 class="font-light text-white">
                     <img src="{{url('/assets/custom/icons/attempt.png')}}" alt="Tests attempted" class="mt-2">
                  </h1>
                  <h6 class="text-white">Tests attempted</h6>
                  <h5 class="text-white">{{count($newdata)}}</h5>
               </div>
            </div>
         </div>
      </div>
        <?php
         $title = array();
            $courses = DB::table('testuploading')
         //   ->where('title', 'not like', "%AIRCAT%")
            ->orderBy('id', 'DESC')
            ->get();
            $newcourses = DB::table('testuploading')
                         ->where('title', 'like', "%AIRCAT%")
                         ->orderBy('id', 'DESC')
                          ->get();
            foreach($newcourses as $newcourse){
               $course_id[] =  $newcourse->id;

            }
        ?>
       
      <!-- dropdownbutton -->
      <!-- Example single danger button -->
      <button class="btn btn-danger mt-3 dropdown-toggle ml-auto " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
         Select Test Type
      </button>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        
           @foreach($courses as $course)
              <?php
                 $useremail =  DB::table('studentlogs')
                                ->where('id',$userid)
                                ->first();
                 
                 $assign_test = DB::table('assign_test')
                             ->where('email',$useremail->email)
                             ->where('course_id',$course->title)
                             ->where('status',1)
                             ->first();
                  //$title[] =  $course->title;
                 
                 ?>
               @if($assign_test)
                  <a class="dropdown-item newcenter" data-id ="{{$course->id}}" data-name ="{{$course->title}}"href="#">{{$course->title}}</a>
               @endif
            @endforeach
            <?php
             //dd($title);
             $valueToCheck = "AIRCAT";
            ?>
      </div>
      <!-- end dropdownbuttton -->
      <div class="card mt-4">
         <div class="card-body">
           
               <table class="table w-100 text-center table-bordered table-striped " >
                  <thead>
                     <tr>
                        <th class="w-50">Test Name</th>
                        <th>Test duration (in Min.)</th>
                        <!--<th>Score</th>-->
                        <th>Action</th>
                     </tr>
                  </thead>
                  <!--noaircatdata-->
                  <tbody class="mytable"> 
                  </tbody>
                  <!--endnoaircatdat--> 
                  <!--aircatdata--->
                  <tbody class="nomytable"> 
                  <?php
                   $userid =session()->get('id');
                   $test = DB::table('tests')
                           ->whereIn('course_id',$course_id)
                           ->get();
               foreach($test as $tests)
               {
                $duration = DB::table('quiz_durations')
                           ->where('test_id',$tests->id)
                           ->orderBy('id','desc')
                          ->first(); 
                $status = DB::table('publish_statuses')
                        ->where('test_id',$tests->id)
                       // ->where('course_id', $request->course_id)
                       
                        ->orderBy('id', 'desc')
                        ->first();
                        
                            $vquizz = DB::table('half_student_quiz')
                                    ->where('test_id',$tests->id)
                                    ->where('user_id',$userid)
                                    ->where('section_name', 'like', "%verbal%")
                                    ->orderBy('id', 'desc')
                                    ->first();
                        
                            if(isset($vquizz)){
                                $isverbalquiz = DB::table('student_quizes')
                                        ->where('test_id',$tests->id)
                                        ->where('user_id',$userid)
                                        ->where('paper_id',$vquizz->paper_id)
                                        ->where('section_type', 'like', "%verbal%")
                                        ->orderBy('id', 'desc')
                                        ->first();         
                            }
                            $dquizz = DB::table('half_student_quiz')
                                    ->where('test_id',$tests->id)
                                    ->where('user_id',$userid)
                                   // ->where('section_name', 'like', "%Data%")
                                    ->orderBy('id', 'desc')
                                    ->first();
                          
                            
                        if(isset($dquizz)){
                            $isdataquiz = DB::table('student_quizes')
                                    ->where('test_id',$tests->id)
                                    ->where('user_id',$userid)
                                    ->where('paper_id',$dquizz->paper_id)
                                    ->where('section_type', 'like', "%Data%")
                                    ->orderBy('id', 'desc')
                                    ->first(); 
                                   // dd($isdataquiz);
                        }
                         $qquizz = DB::table('half_student_quiz')
                                    ->where('test_id',$tests->id)
                                    ->where('user_id',$userid)
                                   // ->where('section_name', 'like', "%quantitative%")
                                    ->orderBy('id', 'desc')
                                    ->first();
                        
                         if(isset($qquizz)){
                            $isqtquiz = DB::table('student_quizes')
                                    ->where('test_id',$tests->id)
                                    ->where('user_id',$userid)
                                    ->where('paper_id',$qquizz->paper_id)
                                    ->where('section_type', 'like', "%quantitative%")
                                    ->orderBy('id', 'desc')
                                    ->first();
                        }
                                    
                        $maximum_attemp = DB::table('maximum_attempt_count')
                                        ->where('test_id',$tests->id)
                                        ->orderBy('id', 'desc')
                                         ->first();
                        $alluserquiz = DB::table('student_quizes')
                                        ->where('test_id',$tests->id)
                                        ->where('user_id',$userid)
                                         ->where('section_type', 'like', "%quantitative%")
                                        ->get(); 
                                        
                        $proctored = DB::table('proctored')
                                    ->where('test_id',$tests->id)
                                    ->orderBy('id', 'desc')
                                    ->first();
                        $allid = array();
                        foreach($alluserquiz as $alluserquizs)
                        {
                          $allid[] =   $alluserquizs->id;
                        }
                        
                         $excel_questions = DB::table('excel_questions')
                                 ->where('test_id', $tests->id)
                                 ->get();

                        $section_name = array();
                        foreach ($excel_questions as $excel_question) {
                            $section_name[] = $excel_question->section_name;
                        }
            
                        $sectionArray = $section_name;
                        $search_terms = [
                            'verbal' => 'verbal',
                            'data' => 'data',
                            'quantitative' => 'quantitative'
                        ];
                    
                        $result = [];
                        foreach ($search_terms as $key => $term) {
                            foreach ($sectionArray as $value) {
                                if (stripos($value, $term) !== false) {
                                    $result[] = $key;
                                    break;
                                }
                            }
                        }
                      $result_string = implode(', ', $result);
                      $exploded_array = explode(', ', $result_string);
                                    
                $i = 0;     
                $vti = $duration->verbal_time;
                $dti = $duration->interp_time;
                $qti = $duration->quantitative_time;
                $totime = $vti+$dti+$qti;
                 echo'<tr><td>'.$tests->test.'</td>';
                  echo' <td>'.$totime.'</td>';
                // ' <td>66</td>';
                echo'<td>';
                if($status->status == '1')
                {
                    // if(empty($isverbalquiz) && $vquizz){
                    //       $ssid = 'report';
                    //      if(count($allid) < $maximum_attemp->maximum_attempt)
                    //     {
                    //         if(isset($vquizz)){
                    //         foreach($alluserquiz as $alluserq)
                    //       {
                    //         //if(isset($alluserq)){
                    //             if($i == 0){
                    //              echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    //           }else{
                    //              echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    //           }
                    //           $i++;

                    //         }
                             
                    //       }
                    //       echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
                            
                    //     }else{
                    //       echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
                            
                    //     } 
                    // }elseif(empty($isdataquiz) && (isset($isverbalquiz) && (isset($vquizz)))){
                       
                    //     $sid = 'data';
                    //     $ssid = 'report';
                    //     if(count($allid) < $maximum_attemp->maximum_attempt)
                    //     {
                    //       if(isset($vquizz)){
                    //       foreach($alluserquiz as $alluserq)
                    //       {
                            
                    //           if($i == 0){
                    //              echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    //           }else{
                    //              echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    //           }
                    //           $i++;
                    //         }
                    //       }
                    //       echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
                           
                    //     }else{
                    //          // dd($isverbalquiz);
                    //          echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
                           
                    //     }
                    // }elseif(empty($isqtquiz) && isset($isverbalquiz) && isset($isdataquiz) && isset($vquizz)){
                       
                    //      $sid = 'quantitative';
                    //      $ssid = 'report';
                         
                    //   if(count($allid) < $maximum_attemp->maximum_attempt)
                    //   {
                    //       if(isset($vquizz)){
                    //       foreach($alluserquiz as $alluserq)
                    //       {
                    //         //if(isset($alluserq)){
                    //           if($i == 0){
                    //              echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    //           }else{
                    //              echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    //           }
                    //           $i++;
                    //         }
                    //       }
                    //       echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
                           
                    //   }else{
                    //     echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
                    //   }
                    // }elseif(isset($isverbalquiz) && isset($isdataquiz) && isset($isqtquiz) && isset($vquizz)){
                    //     $sid = 'report';
                    //     if(($alluserquiz)){
                    //         if(count($allid) < $maximum_attemp->maximum_attempt)
                    //         {   
                    //           // if(isset($alluserquiz)){
                    //                 foreach($alluserquiz as $alluserq)
                    //                 {
                    //                     //if(isset($alluserq)){
                    //                     if($i == 0){
                    //                       echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    //                     }else{
                    //                       echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    //                     }
                    //                     $i++;
                    //                 }
                    //             //}
                    //             // '<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                                
                    //                 if(isset($proctored) && $proctored->status == '1'){
                    //                      echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                    //                      echo csrf_field(); 
                    //                      echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code" >';
                    //                      echo'<p class="par'.$tests->id.' text-red"></p>';
                    //                      echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    //                      echo '<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    //                      echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    //                      echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    //                      echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    //                      echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                    //                      echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    //                      echo'</form>';
                    //                 }else{
                    //                   echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro">Launch Test</a>';
                    //                 }
                    //         }else{
                    //             //if(isset($alluserquiz)){
                    //                 foreach($alluserquiz as $alluserq)
                    //                 {
                    //                 if($i == 0){
                    //                   echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    //                 }else{
                    //                   echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    //                 }
                    //                 $i++;
                    //                 }
                    //             //}
                            
                    //         }
                    //     }else{
                    //       echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
                    //     }
                    // }else{
                    //     if(isset($proctored) && $proctored->status == '1'){
                    //       echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    //       echo csrf_field();
                    //       echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code" >';
                    //       echo'<p class="par'.$tests->id.' text-red"></p>';
                    //       echo '<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    //       echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    //       echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    //       echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    //       echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    //       echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                    //       echo '<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    //       echo '</form>';
                    //     }else{
                    //       echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
                    //     }
                      
                    // }
                    
if((in_array('verbal', $exploded_array)) && (in_array('data', $exploded_array))){
    if(empty($isverbalquiz) && $vquizz){
            $ssid = 'report';
        if(count($allid) == $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }  
            }
            echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        }else{
                echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        } 
    }elseif(empty($isdataquiz) && (isset($isverbalquiz) && (isset($vquizz)))){
        $sid = 'data';
        $ssid = 'report';
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }
            }
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white mx-4 resum" >Resume</a>';
            
        }
    }elseif(isset($isverbalquiz) && isset($isdataquiz)  && isset($vquizz)){
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                               
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                      
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                  
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                  
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }

//dd("okk1");
}elseif((in_array('verbal', $exploded_array)) && (in_array('quantitative', $exploded_array))){
    if(empty($isverbalquiz) && $vquizz){
            $ssid = 'report';
        if(count($allid) == $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }  
            }
            echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        }else{
                echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        } 
    }elseif(empty($isqtquiz) && isset($isverbalquiz)  && isset($vquizz)){
            $sid = 'quantitative';
            $ssid = 'report';
            
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($qquizz)){
            foreach($alluserquiz as $alluserq)
            {
                if($i == 0){
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                }else{
                echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                }
                $i++;
            }
            }
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
        }
    }elseif(isset($isverbalquiz)  && isset($isqtquiz) && isset($vquizz)){
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                              
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                      
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                  
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }

//dd("okk2");
}elseif((in_array('data', $exploded_array)) && (in_array('quantitative', $exploded_array))){
    if(empty($isdataquiz) &&  (isset($dquizz))){
        $sid = 'data';
        $ssid = 'report';
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }
            }
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white mx-4 resum" >Resume</a>';
            
        }
    }elseif(empty($isqtquiz)  && isset($isdataquiz) && isset($dquizz)){
            $sid = 'quantitative';
            $ssid = 'report';
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($qquizz)){
            foreach($alluserquiz as $alluserq)
            {
                if($i == 0){
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                }else{
                echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                }
                $i++;
            }
            }
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
        }
    }elseif(isset($isdataquiz) && isset($isqtquiz) && isset($dquizz)){
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                              
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                      
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                   
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                    
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }


//dd("okk3");
}elseif(in_array('verbal', $exploded_array)){
    if(empty($isverbalquiz) && $vquizz){
        $ssid = 'report';
        if(count($allid) == $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }  
            }
            echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        }else{
                echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        }  
    }elseif(isset($isverbalquiz) && isset($vquizz)){
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                                
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                        
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                   
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                    
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }
    //dd("okk4");
}elseif(in_array('data', $exploded_array)){
    if(empty($isdataquiz)  && (isset($dquizz))){
        $sid = 'data';
        $ssid = 'report';
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }
            }
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white mx-4 resum" >Resume</a>';
            
        }
    }elseif( isset($isdataquiz) && isset($dquizz)){
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                               
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                       
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                   
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                  
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }
     //dd("okk5");
}elseif(in_array('quantitative', $exploded_array)){
   //dd("okk6");
    if(empty($isqtquiz)  && isset($qquizz)){
        $sid = 'quantitative';
        $ssid = 'report';
            
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($qquizz)){
            foreach($alluserquiz as $alluserq)
            {
                if($i == 0){
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                }else{
                echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                }
                $i++;
            }
            }
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
        }
    }elseif(isset($isqtquiz) && isset($qquizz)){
        
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                               
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                       
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                    
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                  
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }

}
}elseif((in_array('verbal', $exploded_array)) && (in_array('data', $exploded_array)) && (in_array('quantitative', $exploded_array))){
    if(empty($isverbalquiz) && $vquizz){
        $ssid = 'report';
        if(count($allid) == $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }  
            }
            echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/start-quize/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum">Resume</a>';
        } 
    }elseif(empty($isdataquiz) && (isset($isverbalquiz) && (isset($vquizz)))){
        $sid = 'data';
        $ssid = 'report';
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($vquizz)){
                foreach($alluserquiz as $alluserq)
                {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$vquizz->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                }
            }
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/data-quiz/'.$sid.'/'.$tests->id.'/'.$dquizz->paper_id.'" class="btn btn-danger btn-sm text-white mx-4 resum" >Resume</a>';
            
        }
    }elseif(empty($isqtquiz) && isset($isverbalquiz) && isset($isdataquiz) && isset($vquizz)){
            $sid = 'quantitative';
            $ssid = 'report';
            
        if(count($allid) < $maximum_attemp->maximum_attempt)
        {
            if(isset($qquizz)){
            foreach($alluserquiz as $alluserq)
            {
                if($i == 0){
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                }else{
                echo'<a  href ="https://test.mbaguru.in/student/report/'.$ssid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                }
                $i++;
            }
            }
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
            
        }else{
            echo'<a  href ="https://test.mbaguru.in/student/quantitative-quiz/'.$sid.'/'.$tests->id.'/'.$qquizz->paper_id.'" class="btn btn-danger btn-sm text-white resum" >Resume</a>';
        }

    }elseif(isset($isverbalquiz) && isset($isdataquiz) && isset($isqtquiz) && isset($vquizz)){
        $sid = 'report';
        if(($alluserquiz)){
            if(count($allid) < $maximum_attemp->maximum_attempt)
            {   
                    foreach($alluserquiz as $alluserq)
                    {
                        //if(isset($alluserq)){
                        if($i == 0){
                                echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                        }else{
                        echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                        }
                        $i++;
                    }
                //}
                // echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn">Launch Test</a>';
                    if(isset($proctored) && $proctored->status == '1'){
                        if (strpos($tests->test, "NMAT") !== false) {
                            if($maximum_attemp->maximum_attempt> $paper){
                                // echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                                // echo csrf_field();
                                // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                                // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                                // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                                // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                                // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                                // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                                // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                                
                                // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                                // echo'</form>';
                            }
                        }else{
                        echo'<form action="https://test.mbaguru.in/student/student/save-proctored" method="post" enctype="multipart/form-data">';
                        echo csrf_field();
                        echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                        echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                        echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                        echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                        echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                        echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                        echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                       
                        echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                        echo'</form>';
                        }
                    }else{
                        if (strpos($tests->test, "NMAT") !== false) {
                            echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }else{
                            echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
                        }
                    }
            }else{
                    foreach($alluserquiz as $alluserq)
                    {
                    if($i == 0){
                            echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result</a>';
                    }else{
                    echo'<a  href ="https://test.mbaguru.in/student/report/'.$sid.'/'.$tests->id.'/'.$alluserq->paper_id.'" class="btn btn-info btn-sm text-white" >Result'.$i.'</a>';
                    }
                    $i++;
                    }
            }
        }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
        }
    }else{
        if(isset($proctored) && $proctored->status == '1'){
            if (strpos($tests->test, "NMAT") !== false) {
                if($maximum_attemp->maximum_attempt > $paper){
                    // echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    // echo csrf_field();
                    // echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    // echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    // echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    // echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    // echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    // echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    // echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                   
                    // echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    // echo'</form>';
                }
            }else{
                    echo'<form action="https://test.mbaguru.in/student/save-proctored" method="post" enctype="multipart/form-data">';
                    echo csrf_field();
                    echo'<input type ="text" name ="proctored_code" class="resuminput input-box" data-id="'.$tests->id.'" placeholder="Enter Code"><p class="par'.$tests->id.' text-red"></p>';
                    echo'<input type = "hidden" name="pro_code" value="'.$proctored->pro_code.'">';
                    echo'<input type = "hidden" name="id" value="'.$proctored->id.'">';
                    echo'<input type = "hidden" name="test_id" value="'.$tests->id.'">';
                    echo'<input type = "hidden" name="test_name" value="'.$tests->test.'">';
                    echo'<input type = "hidden" name="course_id" value="'.$tests->course_id.'">';
                    echo'<input type = "hidden" name="status" value="'.$proctored->status.'">';
                   
                    echo'<button type="submit" class="btn py-1 btn-success text-white" id="Launch-test-btn">Launch Test</button>';
                    echo'</form>';

            }
        }else{
            if (strpos($tests->test, "NMAT") !== false) {
                echo'<a href ="https://test.mbaguru.in/student/nmat-instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro" id="Launch-test-btn" id="Launch-test-btn">Launch Test</a>';
            }else{
                echo'<a href ="https://test.mbaguru.in/student/instructions/'.$tests->id.'" class="btn py-1 btn-success text-white pro " id="Launch-test-btn">Launch Test</a>';
            }  
        }
    }
    
    }
               

                echo'</td>';
                echo'</tr>';
               }

            ?>
                  </tbody> 
                  <!--end-->
               </table>
         </div>
      </div>
   </div>
</div>

</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>





@endsection
@section('script')

<script src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
<script>
   //  $('.newcenter').on('click', function (){
   //    $('.nomytable').css('display','none');
   //      var course_id = $(this).attr('data-id');
   //      var course_name = $(this).attr('data-name');
   //      var url1 =  "{{route('student.fetch-test-record')}}";
   //      $(".mytable").html('');
   //      $.ajaxSetup({
   //            headers: {
   //              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
   //            }
   //      });
   //      $.ajax({
   //          url: url1,
   //          type: "POST",
   //          data: {
   //              course_id: course_id
   //          },
   //          dataType: 'json',
   //          success: function (result) {
   //             $('.mytable').append(result.var_1);
   //             $('.resum').click(function(){
   //                localStorage.clear();
   //             });
   //             $(".resuminput").hover(function(){
   //                var id = $(this).attr('data-id');
   //                $('.par'+id).text('Only applicable for taking test in MBAGuru centres/labs').css('font-size','11px');
   //                }, function(){
   //              });
   //          }
   //      })
   //  })

//$(document).ready(function() {



$('.newcenter').on('click', function() {
    $('.nomytable').css('display', 'none');
    var course_id = $(this).attr('data-id');
    var url1 = "{{ route('student.fetch-test-record') }}";
    $(".mytable").html('');
    $.ajaxSetup({
        headers: {
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: url1,
        type: "POST",
        data: {
            course_id: course_id
        },
        dataType: 'json',
        success: function(result) {
            $('.mytable').append(result.var_1);
            $('.resum').click(function() {
                localStorage.clear();
            });
            $(".resuminput").hover(function() {
                var id = $(this).attr('data-id');
                $('.par' + id).text('Only applicable for taking test in MBAGuru centres/labs').css('font-size', '11px');
            }, function() {
            });
        },
        error: function(jqXHR, textStatus, errorThrown) {
            if (jqXHR.status === 200) {
                location.reload();
                var url2 = "{{ route('student.login') }}";
                window.location.replace(url2);
            } else {
                try {
                    var responseJson = JSON.parse(jqXHR.responseText);
                    console.error('Server Error: ', responseJson.message);
                } catch (e) {
                    console.error('Invalid JSON response from server');
                }
            }
        }
    });
});
//});

</script>
<script>
  //$( document ).ready(function() {
    $('.nonaircat').css('display','none');
        $(".resuminput").hover(
            function () {
               var id = $(this).attr('data-id');
                  $('.par'+id).text('Only applicable for taking test in MBAGuru centres/labs').css('font-size','11px');
            },
            function () {
               var id = $(this).attr('data-id');
               // $('.par'+id).css("display","none");
            }
        );
    //});

</script>
<script>
//    $(window).on('keydown',function(event)
//      {
//      //  console.log(event);
//        if(event.keyCode == 116){
//            return false;
//              //event.preventDefault();
//        }
//        if(event.keyCode == 17){
//           return false; 
//        }else if(event.keyCode == 16){
//            return false;
//        }else if(event.keyCode == 82){
//            return false;
//        }
//      // //   else if(event.keyCode == 116){
//      // //      return false; 
//      // //   }
//      if(event.keyCode==123)
//      {
      
//          return false;
//      }
//      else if(event.ctrlKey && event.shiftKey && event.keyCode==73)
//      {
        
//          return false;  //Prevent from ctrl+shift+i
//      }
//      else if(event.ctrlKey && event.keyCode==73)
//      {
//         // alert('Entered ctrl+shift+i')
//          return false;  //Prevent from ctrl+shift+i
//      }
// });
//  $(document).on("contextmenu",function(e)
//  {
//  return false;
// });
   </script>
@endsection




