@extends('student_template')
@section('css')
@endsection
@section('content')
<style>
    .active
    {
        background-color:white !important;
        color:black !important;
    }
    </style>

    <?php
    $testid = request()->id;
    $paperid = request()->paperid;
    ?>


                        <?php 
                            $q1 = array();
                            $t1 = array();
                            $s1 = array();
                            $c1 = array();
                            $in1 = array();
                            $na1 = array();
                            $to1 = array();
                            $pe1 = array();
                            $fs1 = array();
                            $tc1 = array();
                            $tinct1 = array();
                            $tnt1 = array();
                            $percet = array();
                            $percet1 = array();
                            $inc12 = array();
                            $prci = array();
                            $verbalc = array();
                            $datac = array();
                            $qc = array();
                            $overall = array();
                            ?>       
                          
                            <?php
                              foreach($reports as $key=> $report){
                               $question_id = explode(",",$report->question_id);
                               $timedata = explode(",",$report->ans_duration);
                               $newtm = array_sum($timedata);
                               $t1[] = $newtm;
                              
                               $total_time = date("H:i:s", $newtm / 1000);
                               
                               $ques_ans = DB::table('excel_questions')
                                            ->where('test_id',$report->test_id)
                                            ->whereIn('id', $question_id)
                                            ->get();
                               $question = count($question_id);
                               $q1[] = $question;
                               $answer = explode(",",$report->answer);
                               $ansdata = array();
                               $positive = array();
                               $negative  = array();
                               foreach($ques_ans as $qst)
                               {
                                  $ansdata[] =   $qst->correct_option;
                                  $positive[] = $qst->positive_mark;
                                  $negative[] = $qst->negative_mark;
                                 
                               }
                               $resultt = array_diff_assoc($ansdata, $answer);
                                $correct = array_diff_assoc($ansdata,$resultt);
                               // $inctime = array_intersect_key($timedata,$resultt);
                             

                               $incorrect = count($resultt);
                               $in1[] = $incorrect;
                              
                               
                               $cttr = count($correct);
                               $c1[] = count($correct);
                               $ctime = array_intersect_key($timedata,$correct);

                               $tctime = array_sum($ctime);

                               $tc1[] = $tctime;
                               $fctime = date("H:i:s", $tctime / 1000);
                              
                              $pos = array_intersect_key($positive ,$correct);

                              $pos1 = array_sum($pos);
                               $show_answer1 = array_filter($answer);
                              
                               $show_answer = count($show_answer1); 
                               $inctr =     $show_answer- $cttr;
                                 
                              $inctrr[] =     $show_answer- $cttr;
                            $sdf = array_diff_key($show_answer1,$correct);
                              
                                $inctime = array_intersect_key($timedata,$sdf);
                                 
                               $tinctime = array_sum($inctime);

                               $tinct1[] =  $tinctime;
                               $finctime = date("H:i:s", $tinctime / 1000);
                               $totalinctime =  $tinctime+$tctime;
                                $tolf=   date("H:i:s", $totalinctime / 1000);

                                // echo'<pre>';
                                // print_r($totalinctime );
                             // die;
                              $neg = array_intersect_key($negative , $resultt);
                            //   echo'<pre>';
                            //   print_r($neg);
                              $neg2 =  $inctr*1;
                              $neg1 = array_sum($neg);
                             
                             $totalmark = $pos1 - $neg2;

                             // $totalmark = $pos1 - $neg1;
                              $to1[] = $totalmark; 
                              
                              if(!empty($positive)){
                                  $per = array_sum($positive);
                              }else{
                                   $per = 1;
                              }
                              if($show_answer == 0){
                                  $show_answer123 = 1;
                              }else{
                                  $show_answer123 = $show_answer;
                              }
                             
                             $ctrc =  count($correct);
                             // $per1 = ($totalmark/$per)*100;
                               $per1 = ($ctrc/$show_answer123)*100;
                              //   echo'<pre>';
                              // print_r($per1);
                               $per3 = number_format($per1, 2, '.', '');
                              if($per3 <= -1){
                                  $per2 = 0;
                                  $pe1[] = $per2;
                              }else{
                                  $per2 =  $per3;
                                  $pe1[] = $per2;
                              }
                               $stime = array_intersect_key($timedata,$show_answer1);
                               $tstime = array_sum($stime);
                               $fs1[] = $tstime;
                               $fstime = date("H:i:s", $tstime / 1000);
                                
                                $s1[] = $show_answer; 
                                if(array_keys($question_id ) == array_keys($answer )){
                                   //  dd("okk");
                                    $non_answer1 =   array_intersect($answer, ['']);
                                    $non_answer  = count($non_answer1);
                                    $na1[] = $non_answer;
                                   
                                    $ntime = array_intersect_key($timedata,$non_answer1);
                                   $tntime = array_sum($ntime);
                                   $tnt1[] = $tntime;
                                   $fntime = date("H:i:s", $tntime / 1000);
                                }else{
                                    
                                     $newarr = array_diff_key($question_id, $answer);

                                     $qusarr = count($newarr);
                                     $ansarr1 =  array_intersect($answer, ['']);

                                     $ansarr = count($ansarr1);
                                     $non_answer = $qusarr+$ansarr;

                                     $na1[] = $non_answer;

                                   // //$marr =  array_merge($newarr,$ansarr1);
                                 $marr =     array_intersect_key($ansarr1+$newarr);
                                  // $marr =   array_merge($newarr,$ansarr1);
                                    
                                  //   print_r($ansarr1);
                                    $ntime = array_intersect_key($timedata,$marr);
                                    //  echo'<pre>';
                                    // print_r($ntime);
                                   $tntime = array_sum($ntime);
                                   $tnt1[] = $tntime;
                                   // echo'<pre>';
                                   // print_r($tnt1);
                                   $fntime = date("H:i:s", $tntime / 1000);
                                }
                                     
                              
                               $inc12[] = $inctr;
                               $email = session()->get('email');
                               $prec = DB::table('percentiles')
                               //   ->where('test_id',$report->test_id)
                                  ->where('score', $totalmark)
                                   ->where('section_type', 'like', $report->section_type)
                                   ->orderBy('id',"DESC")
                                    ->first();
                                    //dd($prec);
                                  // $prci[] = $prec->percentile;

                                    $cutoff = DB::table('cutoff')
                                  ->where('test_id',$report->test_id)
                                   //->where('student_email',$email)
                                  // ->where('section_type', 'like', $report->section_type)
                                   ->orderBy('id',"DESC")
                                    ->first();
                                }
                                  
                            ?>
                            <?php
                            $t2  = array_sum($t1);
                            $t3 = date("H:i:s", $t2 / 1000);
                            $fs2 = array_sum($fs1);
                            $fs3 = date("H:i:s", $fs2 / 1000);
                            $tc2 = array_sum($tc1);
                            $tc3 = date("H:i:s", $tc2 / 1000);
                            $tinct2 = array_sum($tinct1);
                            $tinct3 = date("H:i:s", $tinct2 / 1000);
                            $tnt2 = array_sum($tnt1);
                            $tnt3 = date("H:i:s", $tnt2 / 1000);
                            $tnt13 = array_sum($tnt1);
                             $tnt345 = date("H:i:s", $tnt13 / 1000);
                           $s11 = (array_sum($s1));
                           if($s11 == 0){
                              $s11 = 1;
                           }else{
                             $s11 =  (array_sum($s1));
                           }
                           $c11 = (array_sum($c1));
                           $toperpp = ($c11/$s11)*100;
                        

                            ?>
<div class="conatiner-fluid">
   <div class="d-flex  px-4 my-3 justify-content-between align-items-center">
      <h3 class="fw-bold text-capitalize">REPORT</h3>
      <a href="{{route('student.dashboard')}}" class="btn"style="background-color:#A83942;color:white;">HOME</a>
   </div>

   <!-- box image styling starts  -->
    <div class="row px-3 Propzone" id="card-img-style-box">
     
            <div class="col-md-3">
                <div class="card border-0 mx-auto card-img-style " style="background-color: white;">
                    <div class="card-header bg-none py-1  border-0 fs-6 fw-normal" style="color:#808191!important">Score
                    </div>
                    <div class="card-body py-1 ">
                        <h5 class="card-title" style="position: relative;color: #6C5DD3;">
                          {{array_sum($to1)}}
                        </h5>
                        <p class="card-text"></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 mx-auto card-img-style" style="background-color: white;">
                    <div class="card-header bg-none py-1 border-0 fs-6 fw-normal" style="color:#808191!important">Correct Answers
                    </div>
                    <div class="card-body py-1 ">
                        <h5 class="card-title" style="position: relative;color: #2ED480;">
                           {{array_sum($c1)}}
                        </h5>
                        <p class="card-text">
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 mx-auto card-img-style" style="background-color: white;">
                    <div class="card-header bg-none py-1  border-0 fs-6 fw-normal" style="color:#808191!important">
                       Incorrect Answers
                    </div>
                    <div class="card-body py-1 ">
                        <h5 class="card-title" style="position: relative;color: #FD8539;">
                           {{array_sum($inc12)}}
                        </h5>
                        <p class="card-text">
                        </p>
                    </div>
                </div>
            </div> 
            <div class="col-md-3">
                <div class="card border-0 mx-auto card-img-style" style="background-color:white;">
                    <div class="card-header bg-none py-1  border-0 fs-6 fw-normal" style="color:#808191!important">
                        Accuracy %
                    </div>
                    <div class="card-body py-1 ">
                        <h5 class="card-title" style="position: relative;color: #B758E3;">
                          {{round($toperpp, 2)}}
                        </h5>
                        <p class="card-text">
                        </p>
                    </div>
                </div>
            </div>
       
   <!-- display box styling starts-->
    <div class="row my-4">
        <div class="col-md-12 ">
         <h3>Scoredcard</h3>
         </div>
    </div>
    <ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link active" data-bs-toggle="tab" href="#all">All Section</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#difficulty">Difficulty Level</a>
      </li>

       <li class="nav-item">
        <a class="btn btn-default" href="{{route('student.nmat-solution',['testid'=>$testid,'paperid'=>$paperid])}}"><b>Solution</b></a>
      </li>

    </ul>
    <!--startall-->
    <div class="tab-content" >
        <div class="tab-pane active" id="all">
            <div class="row">
                <div class="card col-lg-12 display-box-data">
                    <table class="table mt-2" >
                        <thead class="table-danger">
                            <tr>
                                <th>Name</th>
                                <th>Questions </th>
                                <th>Time Taken</th>
                                <th>Attempt</th>
                                <th>Correct</th>
                                <th>Incorrect</th>
                                <th>Skipped</th>
                                <th>Score</th>
                                <th>Accuracy%</th>
                                <th>Precentile</th>
                                <th>Cut Off</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $q1 = array();
                            $t1 = array();
                            $s1 = array();
                            $c1 = array();
                            $in1 = array();
                            $na1 = array();
                            $to1 = array();
                            $pe1 = array();
                            $fs1 = array();
                            $tc1 = array();
                            $tinct1 = array();
                            $tnt1 = array();
                            $percet = array();
                            $percet1 = array();
                            $inc12 = array();
                            $prci = array();
                            $verbalc = array();
                            $datac = array();
                            $qc = array();
                            $overall = array();
                            ?>       
                            @foreach($reports as $key=> $report)
                            <?php
                               $question_id = explode(",",$report->question_id);
                               $timedata = explode(",",$report->ans_duration);
                            
                               $newtm = array_sum($timedata);
                              
                                $drep = $report->student_duration*60000;
                                if($newtm>$drep){
                                  $total_time = date("H:i:s", $drep / 1000);
                                  $t1[] = $drep;
                                }else{
                                  $total_time = date("H:i:s", $newtm / 1000);
                                  $t1[] = $newtm;
                                }
                               $ques_ans = DB::table('excel_questions')
                                            ->where('test_id',$report->test_id)
                                            ->whereIn('id', $question_id)
                                            ->get();
                               $question = count($question_id);
                               $q1[] = $question;
                               $answer = explode(",",$report->answer);
                               $ansdata = array();
                               $positive = array();
                               $negative  = array();
                               foreach($ques_ans as $qst)
                               {
                                  $ansdata[] =   $qst->correct_option;
                                  $positive[] = $qst->positive_mark;
                                  $negative[] = $qst->negative_mark;
                                 
                               }
                               $resultt = array_diff_assoc($ansdata, $answer);
                                $correct = array_diff_assoc($ansdata,$resultt);
                               // $inctime = array_intersect_key($timedata,$resultt);
                             

                               $incorrect = count($resultt);
                               $in1[] = $incorrect;
                              
                               
                               $cttr = count($correct);
                               $c1[] = count($correct);
                               $ctime = array_intersect_key($timedata,$correct);

                               $tctime = array_sum($ctime);

                               $tc1[] = $tctime;
                               $fctime = date("H:i:s", $tctime / 1000);
                              
                              $pos = array_intersect_key($positive ,$correct);

                              $pos1 = array_sum($pos);
                               $show_answer1 = array_filter($answer);
                              
                               $show_answer = count($show_answer1); 
                               $inctr =     $show_answer- $cttr;
                                 
                              $inctrr[] =     $show_answer- $cttr;
                            $sdf = array_diff_key($show_answer1,$correct);
                              
                                $inctime = array_intersect_key($timedata,$sdf);
                                 
                               $tinctime = array_sum($inctime);

                               $tinct1[] =  $tinctime;
                               $finctime = date("H:i:s", $tinctime / 1000);
                               $totalinctime =  $tinctime+$tctime;
                                $tolf=   date("H:i:s", $totalinctime / 1000);

                                // echo'<pre>';
                                // print_r($totalinctime );
                             // die;
                              $neg = array_intersect_key($negative , $resultt);
                            //   echo'<pre>';
                            //   print_r($neg);
                              $neg2 =  $inctr*1;
                              $neg1 = array_sum($neg);
                             
                             $totalmark = $pos1 - $neg2;

                             // $totalmark = $pos1 - $neg1;
                              $to1[] = $totalmark; 
                              
                              if(!empty($positive)){
                                  $per = array_sum($positive);
                              }else{
                                   $per = 1;
                              }
                              
                              if($show_answer == 0)
                              {
                                  $show_answer123 = 1;
                                  
                              }else{
                                  $show_answer123 = $show_answer;
                                  
                              }
                             
                             $ctrc =  count($correct);
                             // $per1 = ($totalmark/$per)*100;
                               $per1 = ($ctrc/$show_answer123)*100;
                              //   echo'<pre>';
                              // print_r($per1);
                               $per3 = number_format($per1, 2, '.', '');
                              if($per3 <= -1){
                                  $per2 = 0;
                                  $pe1[] = $per2;
                              }else{
                                  $per2 =  $per3;
                                  $pe1[] = $per2;
                              }
                               $stime = array_intersect_key($timedata,$show_answer1);
                               $tstime = array_sum($stime);
                               $fs1[] = $tstime;
                               $fstime = date("H:i:s", $tstime / 1000);
                                
                                $s1[] = $show_answer; 
                                if(array_keys($question_id ) == array_keys($answer )){
                                   //  dd("okk");
                                    $non_answer1 =   array_intersect($answer, ['']);
                                    $non_answer  = count($non_answer1);
                                    $na1[] = $non_answer;
                                   
                                    $ntime = array_intersect_key($timedata,$non_answer1);
                                   $tntime = array_sum($ntime);
                                   $tnt1[] = $tntime;
                                   $fntime = date("H:i:s", $tntime / 1000);
                                }else{
                                    
                                     $newarr = array_diff_key($question_id, $answer);

                                     $qusarr = count($newarr);
                                     $ansarr1 =  array_intersect($answer, ['']);

                                     $ansarr = count($ansarr1);
                                     $non_answer = $qusarr+$ansarr;

                                     $na1[] = $non_answer;

                                 $marr =     array_intersect_key($ansarr1+$newarr);
                                    $ntime = array_intersect_key($timedata,$marr);
                                   $tntime = array_sum($ntime);
                                   $tnt1[] = $tntime;
                                   $fntime = date("H:i:s", $tntime / 1000);
                                }
                                     
                              
                               $inc12[] = $inctr;
                               $email = session()->get('email');
                               $prec = DB::table('percentiles')
                                  ->where('score', $totalmark)
                                   ->where('section_type', 'like', $report->section_type)
                                   ->orderBy('id',"DESC")
                                    ->first();

                                  $cutoff = DB::table('cutoff')
                                            ->where('test_id',$report->test_id)
                                            ->orderBy('id',"DESC")
                                            ->first();
                                  
                            ?>

                            <tr>
                                @if($report->section_type == 'Quantitative Skills')
                                <td>Quantitative Skills</td>
                                @elseif($report->section_type == 'Language Skills')
                                <td>Language Skills</td>
                                @elseif($report->section_type == 'Logical Reasoning')
                                <td>Logical Reasoning</td>
                                @else
                                <td>Overall</td>
                                @endif
                                <td>{{$question}}</td>
                                <td>{{$total_time}}</td>
                                <td>{{$show_answer}}<br>({{$tolf}})</td>
                                <td>{{count($correct)}}<br>({{$fctime}})</td>
                                <td>{{$inctr}}<br>({{$finctime}})</td>
                                <td>{{$non_answer}}<br>({{$fntime}})</td>
                                <td>{{$totalmark}}</td>
                                <td>{{$per2}}</td>
                                <?php
                                if(!empty($prec)){
                                  $prece =  round($prec->percentile, 2); 
                                }
                               

                                ?>
                                @if($report->section_type == 'Quantitative Skills')
                                    @if(!empty($prec))

                                    <td>{{$prece}}</td>
                                    @else
                                   <td>-</td>
                                   @endif
                                @elseif($report->section_type == 'Language Skills')
                                 @if(!empty($prec))
                                    <td>{{$prece}}</td>
                                    @else
                                   <td>-</td>
                                   @endif
                                @elseif($report->section_type == 'Logical Reasoning')
                               @if(!empty($prec))
                                    <td>{{$prece}}</td>
                                    @else
                                   <td>-</td>
                                   @endif
                                @else
                                <td>-</td>
                                @endif
                                
                                @if($report->section_type == 'verbal')
                                  @if(!empty($prec))
                                <td>{{$cutoff->verbal_cutoff}}</td>
                                  @else
                                   <td>-</td>
                                   @endif
                                @elseif($report->section_type == 'data')
                                  @if(!empty($prec))
                                 <td>{{$cutoff->data_cutoff}}</td>
                                  @else
                                   <td>-</td>
                                   @endif
                                @elseif($report->section_type == 'quantitative')
                                  @if(!empty($prec))
                              <td>{{$cutoff->quantitative_cutoff}}</td>
                               @else
                                   <td>-</td>
                                   @endif
                                @else
                                <td>-</td>
                                 @endif
                            </tr>
                       
                            @endforeach
                            <?php
                         

                            $t2  = array_sum($t1);
                            $t3 = date("H:i:s", $t2 / 1000);
                            $fs2 = array_sum($fs1);
                            $fs3 = date("H:i:s", $fs2 / 1000);
                            $tc2 = array_sum($tc1);
                            $tc3 = date("H:i:s", $tc2 / 1000);
                            $tinct2 = array_sum($tinct1);
                            $tinct3 = date("H:i:s", $tinct2 / 1000);
                            $tnt2 = array_sum($tnt1);
                            $tnt3 = date("H:i:s", $tnt2 / 1000);
                            $tnt13 = array_sum($tnt1);
                             $tnt345 = date("H:i:s", $tnt13 / 1000);
                           $s11 = (array_sum($s1));
                           if($s11 == 0){
                               $s11 = 1;
                           }else{
                               $s11 = (array_sum($s1));
                           }
                           $c11 = (array_sum($c1));
                           $toperpp = ($c11/$s11)*100;
                        

                            ?>
                            <tr>
                                <td>Overall</td>
                                <td>{{array_sum($q1)}}</td>
                                <td>{{$t3}}</td>
                                <td>{{array_sum($s1)}}<br>({{$fs3}})</td>
                                <td>{{array_sum($c1)}}<br>({{$tc3}})</td>
                                <td>{{array_sum($inc12)}}<br>({{$tinct3}})</td>
                                <td>{{array_sum($na1)}}<br>({{$tnt345}})</td>
                                <td>{{array_sum($to1)}}</td>
                                <!-- <td>{{array_sum($pe1)}}</td> -->
                                 <td>{{round($toperpp, 2)}} </td>
                                 <td>-</td>
                                  <td>-</td>
                                <!-- <td>{{array_sum($prci)}}</td> -->
                            </tr>
                    </tbody>
                   </table>
                </div>
            </div>
        </div>
    </div>

     
    <!--endall-->
    <!--startdiff-->
    <div class="tab-content" >
        <div class="tab-pane " id="difficulty">
           <div class="row">
        <div class="card col-lg-12 ">
            <table class="table mt-2">
                <thead class="table table-danger w-100">
                    <tr>
                        <th class="float-left">Name</th>
                        <th> Questions </th>
                        <th>Time Taken</th>
                        <th>Attempt</th>
                        <th>Correct</th>
                        <th>Incorrect</th>
                        <th>Skipped</th>
                        <th>Score</th>
                        <th>Accuracy%</th>
                        
                    </tr>
                </thead>
                <tbody class="table">
                        <?php
                        $userid =session()->get('id');
                        $id =request()->id;
                        $paperid =request()->paperid;
                        $idata = array();
                        $mdata = array();
                        $edata = array();
                        $du = array();
                        $resultt = array();
                        $iandata = array();
                        $show_ans = array();
                        $corr = array();
                        $non_answeri = array();
                        $positivei = array();
                        $negativei =  array();
                        $totalmarki = array();
                        $peri2 = array();
                        $newtimedata = array();
                        $netimecorr = array();
                        $mco = array();
                        $eco = array();

                        $medi = DB::table('student_quizes')
                                    ->where('test_id',$id)
                                     ->where('user_id',$userid)
                                     ->where('paper_id',$paperid)
                                     ->get();

                           
                                    $ans = array();
                                     $ans1 = array();
                            foreach($medi as  $medis)
                            { 
                            $idf  = explode(',', $medis->question_id);
                            $du[] = explode(',',  $medis->ans_duration);
                            $duu = explode(',',  $medis->ans_duration);
                            $answer = explode(',',  $medis->answer);      
                           $show_ans[] = array_filter($answer);


                            //$show_ans[] = count($show_an); 
                            $ins = DB::table('excel_questions')
                                ->where('test_id',$id)
                                ->whereIn('id',$idf)
                                ->where('level','INTENSE')
                                 ->get();

                             $md = DB::table('excel_questions')
                            ->where('test_id',$id)
                            ->whereIn('id',$idf)
                            ->where('level','MEDIUM')
                            ->get(); 
                             $es = DB::table('excel_questions')
                            ->where('test_id',$id)
                            ->whereIn('id',$idf)
                            ->where('level','EASY')
                            ->get(); 
                               foreach($ins as $inss){
                                    $idata[] =  $inss->id;
                                    $iansdata[]  = $inss->correct_option;
                                    $positivei[] = $inss->positive_mark;
                                    $negativei[] = $inss->negative_mark;
                                    
                                }
                              
                            $resultt[] = array_diff_assoc($iansdata,$answer);
                            $resulttt = array_diff_assoc($iansdata,$answer);
                           // $corr[] = array_diff_assoc($iansdata,$resulttt);
                           
                            if(array_keys($question_id ) == array_keys($answer )){
                                    $non_answer1 =   array_intersect($answer, ['']);
                                   $non_answeri[]  = count($non_answer1);
                                }else{
                                     $newarr = array_diff_key($question_id, $answer);
                                     $qusarr = count($newarr);
                                     $ansarr1 =  array_intersect($answer, ['']);
                                     $ansarr = count($ansarr1);
                                     $non_answeri[] = $qusarr+$ansarr;
                                }
                              

                              $pos = array_intersect_key($positive ,$correct);
                            
                              $pos1 = array_sum($pos);
                              $neg = array_intersect_key($negative ,$resultt);
                              $neg1 = array_sum($neg);
                              $totalmarky =  $pos1 - $neg1;
                              $totalmarki[] = $pos1 - $neg1;

                               $per = array_sum($positive);
                              $per1 = ($totalmarky/$per)*100;

                               $per3 = number_format($per1, 2, '.', '');
                              if($per3 <= -1){
                                  $peri2[] = 0;
                                  $pe1[] = $per2;
                              }else{
                                  $peri2[] =  $per3;
                                  $pe1[] = $per2;
                              }

                                 foreach($md as $mds){
                                   $mdata[] =  $mds->id;
                                    $mco[]  = $mds->correct_option;
                                }
                                // echo'<pre>';
                                // print_r($mdata);
                                foreach($es as $ess){
                                   $edata[] =  $ess->id;
                                   $eco[]  = $ess->correct_option;
                                }
                                 
                            }
                            

                             
                             $idata1 = array_unique($idata);
                             $mdata1 = array_unique($mdata);
                             $edata1 =  array_unique($edata);


                          $val0 =  array_intersect_key($show_ans[0],$idata1);
                          $val1 =  array_intersect_key($show_ans[1],$edata1);
                          $val2 =  array_intersect_key($show_ans[2],$mdata1);

                          $corr[0] = array_intersect($val0,$iansdata);
                          $corr[1] = array_intersect($val1,$eco);
                          $corr[2] = array_intersect($val2,$mco);


                             // $show_answer = count($show_answer1); 
                              $du1 = $du[0];
                            $du111 = array_sum($du1);
                           
                              $du11 = date("H:i:s", $du111 / 1000);

                              $du2 = $du[1];
                             $du222 = array_sum($du2);
                             $du22 = date("H:i:s",  $du222 / 1000);
                              $du3 = $du[2]; 
                              $du333 = array_sum($du3);
                              $du33 = date("H:i:s", $du333 / 1000); 

                              // $ione= (count($show_ans[0])) - (count($corr[0]));
                              $ione= (count($val0)) - (count($corr[0]));
                                //  echo'<pre>';
                                // print_r($idata1);
                                // print_r($val0);
                                // print_r($corr[2]);
                                //prnt_r($val0);

                              // $itwo = (count($idata1)) - (count($show_ans[0]));
                                $itwo = (count($idata1)) - (count($val0));

                              // $eone= (count($show_ans[1])) - (count($corr[1]));

                              $eone= (count($val1)) - (count($corr[1]));

                              // $etwo = (count($edata1)) - (count($show_ans[1]));
                               $etwo = (count($edata1)) - (count($val1));

                              // $mone= (count($show_ans[2])) - (count($corr[2]));
                               $mone= (count($val2)) - (count($corr[2]));
                              // $mtwo = (count($mdata1)) - (count($show_ans[2]));
                                 $mtwo = (count($mdata1)) - (count($val2));



                              $pos0 = array_intersect_key($positive,$corr[0]);
                             

                              $pos1 = array_intersect_key($positive,$corr[1]);
                              $pos2 = array_intersect_key($positive,$corr[2]);
                           

                               $pos00 = count($val0);
                               if($pos00 == 0){
                                  $pos009 =1; 
                               }else{
                                   $pos009 = count($val0); 
                               }
                               $cpos00 = count($corr[0]);
                                $prs0 =  (($cpos00/$pos009)*100);

                                $pos11 = count($val1);
                               $cpos11 = count($corr[1]);
                               if($pos11 == 0){
                                   $pos1123 = 1;
                               }else{
                                  $pos1123 = $pos11;
                               }
                                $prs1 =  (($cpos11/$pos1123)*100);

                                 $pos22 = count($val2);
                                 if($pos22 == 0){
                                    $pos22 = 1; 
                                 }else{
                                   $pos22 = count($val2);  
                                 }
                               $cpos22 = count($corr[2]);
                                $prs2 =  (($cpos22/$pos22)*100);
                               $cuti= count($corr[0]);
                                   if($cuti == 0)
                                   {
                                    $cutii =1;

                                   } else{
                                    $cutii = $cuti;
                                   }

                            $acuu0=  (count($show_ans[0])/$cutii);
                              

                              $netimecorr0 = array_intersect_key($du[0],$corr[0]);
                              $netimecorr00 = array_sum($netimecorr0);
                              $netimecorr000= date("H:i:s", $netimecorr00 / 1000);

                               $netimecorr1 = array_intersect_key($du[1],$corr[1]);
                               $netimecorr11 = array_sum($netimecorr1);
                              $netimecorr111= date("H:i:s", $netimecorr11 / 1000);

                               $netimecorr2 = array_intersect_key($du[2],$corr[2]);

                              $netimecorr22 = array_sum($netimecorr2);
                              $netimecorr222= date("H:i:s", $netimecorr22 / 1000);

                            $netimeatt0 = array_intersect_key($du[0],$show_ans[0]);
                            $netimeatt00 = array_sum($netimeatt0);
                            $netimeatt000= date("H:i:s", $netimeatt00 / 1000);


                            $netimeatt1 = array_intersect_key($du[1],$show_ans[1]);
                            $netimeatt11 = array_sum($netimeatt1);
                            $netimeatt111= date("H:i:s", $netimeatt11 / 1000);


                             $netimeatt2 = array_intersect_key($du[2],$show_ans[2]);
                            $netimeatt22 = array_sum($netimeatt2);
                            $netimeatt222= date("H:i:s", $netimeatt22 / 1000);
                            


                            $subinc0 = $netimeatt00-$netimecorr00;
                             $totics0= date("H:i:s", $subinc0 / 1000);

                              $subinc1 = $netimeatt11-$netimecorr11;
                             $totics1= date("H:i:s", $subinc1 / 1000);

                             $subinc2 = $netimeatt22-$netimecorr22;
                             $totics2= date("H:i:s", $subinc2 / 1000);


                          $skp0 =  $du111-$netimeatt00;
                          $skp00= date("H:i:s", $skp0 / 1000);

                            $skp1 =  $du222-$netimeatt11;
                          $skp11= date("H:i:s", $skp1 / 1000);

                          $skp2 =  $du333-$netimeatt22;
                          $skp22= date("H:i:s", $skp2 / 1000);

                       
                         $tpos0 = array_sum($pos0) - $ione;   
                         $tpos1 = array_sum($pos1) - $eone;
                         $tpos2 = array_sum($pos2) - $mone;
                        ?>
                        <tr>
                            <td>INTENSE</td>
                            <td>{{count($idata1)}}</td>
                            <td>{{$du11}}</td>
                             <!-- <td>{{count($show_ans[0])}} -->
                                <td>{{count($val0)}}
                                <br/>({{$netimeatt000}})</td>
                              <td>{{count($corr[0])}}<br/>({{$netimecorr000}})</td>
                              <!-- <td>{{count($resultt[0])}}</td> -->
                              <td>{{$ione}}<br/>({{$totics0}})</td>
                              <!-- <td>{{$non_answeri[0]}}</td> -->
                              <td>{{$itwo}}<br/>({{$skp00}})</td>
                              <!-- <td>{{$totalmarki[0]}}</td> -->
                             <!-- <td> {{array_sum($pos0)}}</td> -->
                             <td> {{$tpos0}}</td>
                             
                               <!-- <td>{{$prs0}}</td> -->
                                <td>{{round($prs0, 2)}}</td> 
                              
                        </tr>
                        <tr>
                            <td>EASY</td>
                            <td>{{count($edata1)}}</td>
                            <td>{{$du22}}</td>
                            <!-- <td>{{count($show_ans[1])}} -->
                                 <td>{{count($val1)}}
                                <br/>({{$netimeatt111}})</td>
                             <td>{{count($corr[1])}}<br/>({{$netimecorr111}})</td>
                              <!-- <td>{{count($resultt[1])}}</td> -->
                               <td>{{$eone}}<br/>({{$totics1}})</td>
                              <!-- <td>{{$non_answeri[1]}}</td> -->
                               <td>{{$etwo}}<br/>({{$skp11}})</td>
                              <!-- <td>{{$totalmarki[1]}}</td> -->
                              <!-- <td> {{array_sum($pos1)}}</td> -->
                              <td> {{$tpos1}}</td>
                              <!-- <td>{{$peri2[1]}}</td> -->
                              <!-- <td>{{$prs1}}</td> -->
                              <td>{{round($prs1, 2)}}</td> 
                              
                        </tr>
                        <tr>
                            <td>MEDIUM</td>
                            <td>{{count($mdata1)}}</td>
                            <td>{{$du33}}</td>
                            <!-- <td>{{count($show_ans[2])}} -->
                                <td>{{count($val2)}}
                                <br/>({{$netimeatt222}})</td>
                             <td>{{count($corr[2])}}<br/>({{$netimecorr222}})</td>
                             <!-- <td>{{count($resultt[2])}}</td> -->
                                <td>{{$mone}}<br/>({{$totics2}})</td>
                             <!-- <td>{{$non_answeri[2]}}</td> -->
                              <td>{{$mtwo}}<br/>({{$skp22}})</td>
                              <!-- <td>{{$totalmarki[2]}}</td> -->
                              <!-- <td> {{array_sum($pos2)}}</td> -->
                               <td> {{$tpos2}}</td>
                              <!-- <td>{{$peri2[0]}}</td> -->
                              <td>{{round($prs2, 2)}}</td> 
                              <!-- <td>{{$prs2}}</td> -->
                               
                        </tr>
                     </tdody>
        </table>
    </div>
</div>
        </div>
    </div>
    <!--enddiff-->
    <div class="container col-md-12" style="margin-top: 10px; margin-bottom:10px;">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs">

                  <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#msg">Quantitative Skills</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#pro">Language Skills</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#set">Logical Reasoning</a>
                  </li>
                </ul>
                <div class="tab-content" >
                    <div class="tab-pane active" id="msg">
                        <div class="col-md-12 ">
                            <div class="card bg-white display-box-data ">
                                <table class="table w-100 ">
                                    <thead class="table-danger">
                                        <tr>
                                            <th>S.No</th>
                                            <th style="width:700px;">Question </th>
                                            <!-- <th>Your Answer</th> -->
                                            <th>Correct Answer</th>
                                            <th>Difficulty Level</th>
                                            <th>Time Taken</th>
                                            <th>Marks</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        //   echo'<pre>';
                                        //  print_r($verbal_reports);
                                        //  die;
                                        $i=1;
                                        $paperid =request()->paperid;
                                         $id =request()->id;
                                         $qus_id = explode(',', $verbal_reports->ans_duration);
                                         $ans = explode(',', $verbal_reports->answer);
                                       
                                        $userid =session()->get('id');
                                        ?>
                                        @foreach($verbal_ques as $key=> $que)
                                         <?php
                                      $qrts = strip_tags($que->question);
                                      $smallq = substr($qrts, 0, 150);
                                    
                                      ?>
                                        <tr>
                                            <td>{{$i}}</td>
                                            <td style="text-align:justify">
                                               <span class="first{{$i}}"><?=$smallq;?></span>
                                                <span class="second{{$i}}" style="display:none;"><?=$qrts;?></span>
                                                <button class="tsl more{{$i}}" data-set="{{$i}}">Read More</button>  
                                                 <button class="tsd less{{$i}}" data-set="{{$i}}" style="display:none">Read Less</button>             
                                            </td>
                                            <!-- <td>C</td> -->
                                            @if($que->correct_option == '1')
                                            <td>A</td>
                                            @elseif($que->correct_option == '2')
                                            <td>B</td>
                                            @elseif($que->correct_option == '3')
                                            <td>C</td>
                                            @elseif($que->correct_option == '4')
                                            <td>D</td>
                                            @else
                                             <td>{{$que->correct_option}}</td>
                                             @endif
                                            <td>{{$que->level}}</td>
                                            @foreach($qus_id as $key1=> $qus_ids)
                                            <?php
    
                                            $qtime = date("H:i:s", $qus_ids / 1000);
                                            ?>  
                                             @if($key == $key1)
                                            <td>{{$qtime}}</td>
                                            @endif
                                            @endforeach
                                            <td>{{$que->positive_mark}}</td>
                                        </tr>
                                        <?php
                                        $i++;
                                        ?>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                      <div class="tab-pane fade" id="pro">
                       
                        <div class="col-md-12 px-2">
                        <div class="card bg-white display-box-data">
                            <table class="table w-100 ">
                                <thead class="table-danger">
                                    <tr>
                                        <th>S.No</th>
                                            <th>Question </th>
                                            <!-- <th>Your Answer</th> -->
                                            <th>Correct Answer</th>
                                            <th>Difficulty Level</th>
                                            <th>Time Taken</th>
                                            <th>Marks</th>

                                    </tr>
                                </thead>
                                    <tbody>
                                        <?php
                                          $qus_id = explode(',', $data_reports->ans_duration);
                                          
                                        $i=1;
                                        ?>
                                        @foreach($data_ques as $key => $que)
                                       <?php
                                      $qrts = strip_tags($que->question);
                                      $smallq = substr($qrts, 0, 150);
                                     // dd($smallq);
                                      ?>
                                        <tr>
                                            <td>{{$i}}</td>
                                            <td style="text-align:justify">
                                               <span class="first{{$i}}"><?=$smallq;?></span>
                                                <span class="second{{$i}}" style="display:none;"><?=$qrts;?></span>
                                                <button class="tsl more{{$i}}" data-set="{{$i}}">Read More</button>  
                                                 <button class="tsd less{{$i}}" data-set="{{$i}}" style="display:none">Read Less</button>             
                                            </td>
                                            <!-- <td>C</td> -->
                                            @if($que->correct_option == '1')
                                            <td>A</td>
                                            @elseif($que->correct_option == '2')
                                            <td>B</td>
                                            @elseif($que->correct_option == '3')
                                            <td>C</td>
                                            @elseif($que->correct_option == '4')
                                            <td>D</td>
                                            @else
                                             <td>{{$que->correct_option}}</td>
                                             @endif
                                            <td>{{$que->level}}</td>
                                             @foreach($qus_id as $key1=> $qus_ids)
                                            <?php
    
                                            $qtime = date("H:i:s", $qus_ids / 1000);
                                            ?>  
                                             @if($key == $key1)
                                            <td>{{$qtime}}</td>
                                            @endif
                                            @endforeach
                                            <td>{{$que->positive_mark}}</td>
                                        </tr>
                                        <?php
                                        $i++;
                                        ?>
                                        @endforeach
                                    </tbody>
                            </table>
                        </div>
                    </div>
                      </div>
                      <div class="tab-pane  fade" id="set">
                          <div class="col-md-12 ">
                        <div class="card bg-white display-box-data">
                            <table class="table w-100 ">
                                <thead class="table-danger">
                                    <tr>
                                            <th>S.No</th>
                                            <th>Question </th>
                                            <!-- <th>Your Answer</th> -->
                                            <th>Correct Answer</th>
                                            <th>Difficulty Level</th>
                                            <th>Time Taken</th>
                                            <th>Marks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                        <?php
                                         $qus_id = explode(',', $qt_reports->ans_duration);
                                        $i=1;

                                        ?>
                                        @foreach($qt_ques as $key=> $que)
                                      <?php
                                      $qrts = strip_tags($que->question);
                                      $smallq = substr($qrts, 0, 150);
                                     // dd($smallq);
                                      ?>
                                        <tr>
                                            <td>{{$i}}</td>
                                            <td style="text-align:justify">
                                               <span class="first{{$i}}"><?=$smallq;?></span>
                                                <span class="second{{$i}}" style="display:none;"><?=$qrts;?></span>
                                                <button class="tsl more{{$i}}" data-set="{{$i}}">Read More</button>  
                                                 <button class="tsd less{{$i}}" data-set="{{$i}}" style="display:none">Read Less</button>             
                                            </td>
                                           
                                            <!-- <td>C</td> -->
                                            @if($que->correct_option == '1')
                                            <td>A</td>
                                            @elseif($que->correct_option == '2')
                                            <td>B</td>
                                            @elseif($que->correct_option == '3')
                                            <td>C</td>
                                            @elseif($que->correct_option == '4')
                                            <td>D</td>
                                            @else
                                             <td>{{$que->correct_option}}</td>
                                             @endif
                                            <td>{{$que->level}}</td>
                                            @foreach($qus_id as $key1=> $qus_ids)
                                            <?php
    
                                            $qtime = date("H:i:s", $qus_ids / 1000);
                                            ?>  
                                             @if($key == $key1)
                                            <td>{{$qtime}}</td>
                                            @endif
                                            @endforeach
                                            <td>{{$que->positive_mark}}</td>
                                        </tr>
                                        <?php
                                        $i++;
                                        ?>
                                        @endforeach
                                    </tbody>
                            </table>
                        </div>
                    </div>
                      </div>
                </div>
                <!-- end Tab panes -->
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    $(".tsl").click(function() {
      var set = $(this).attr('data-set');
      $(".second"+set).css('display','block');
      $(".first"+set).css('display','none');
      $('.less'+set).css('display','block');
      $('.more'+set).css('display','none');
    });
});

    $(document).ready(function() {
    $(".tsd").click(function() {
      var set = $(this).attr('data-set');
      $(".second"+set).css('display','none');
      $(".first"+set).css('display','block');
      $('.less'+set).css('display','none');
      $('.more'+set).css('display','block');
    });
});
</script>
@endsection


@section('script')

@endsection
